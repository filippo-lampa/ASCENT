const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class PLROperator {
    constructor() {
        this.ID = "PLR";
        this.name = "precision-loss-replacement";
    }

    getMutations(file, source, visit) {
        const mutations = [];

        visit({
            BinaryOperation: (node) => {

                //First-Level BinOp should be a division or a multiplication
                if (node.operator && (node.operator === "*") || node.operator === "/") {

                    if (node.left.type === "BinaryOperation") {
                        if (node.left?.left && node.left?.right &&
                            (node.operator === "*" && node.left.operator === "/") ||
                            (node.operator === "/" && node.left.operator === "*")) {
                            mutateLeftAssociative(visit, node, node.left.left, node.left, node.right);
                        }
                    }
                    else if (node.right.type === "BinaryOperation") {
                        if (node.right?.left && node.right?.right &&
                            (node.operator === "*" && node.right.operator === "/") ||
                            (node.operator === "/" && node.right.operator === "*")) {
                            mutateRightAssociative(visit, node, node.left, node.right.left, node.right);
                        }
                    }
                    else if (node.left.type === "TupleExpression") {
                        let nodeLeft = node.left.components[0].type === "BinaryOperation" ? node.left.components[0] : null;
                        if (nodeLeft !== null && nodeLeft.left && nodeLeft.right &&
                            (node.operator === "*" && nodeLeft?.operator === "/") ||
                            (node.operator === "/" && nodeLeft?.operator === "*")) {
                            mutateLeftAssociative(visit, node, nodeLeft.left, nodeLeft, node.right);
                        }
                    } else if (node.right.type === "TupleExpression") {
                        let nodeRight = node.right.components[0].type === "BinaryOperation" ? node.right.components[0] : null;
                        if (nodeRight !== null && nodeRight?.left && nodeRight?.right &&
                            (node.operator === "*" && nodeRight?.operator === "/") ||
                            (node.operator === "/" && nodeRight?.operator === "*")) {
                            mutateRightAssociative(visit, node, node.left, nodeRight.left, nodeRight);
                        }
                    }
                }
            },
        });

        /**
         * Switch order of operations associated to the left
         * original: (a * b) / c, replacement: (a / c) * b
         * original: a / b * c, replacement: a * c / b
         * identifier (a), firstOperation (* b), secondOperation (/ c)
         * @param {*} visit the visitor
         * @param {Object} node the binary expression node
         * @param {Object} fixedElementNode the fixed element (a)
         * @param {Object} firstOpNode the first operation node ( operator b )
         * @param {Object} secondOpNode the second operation node ( operator c )
         */
        function mutateLeftAssociative(visit, node, fixedElementNode, firstOpNode, secondOpNode) {
            const start = node.range[0];
            const end = node.range[1] + 1;
            const startLine = node.loc.start.line;
            const endLine = node.loc.end.line;
            const functionName = contextParser.getFunctionName(visit,startLine,endLine);
            const original = source.slice(start, end);
            const fixedElement = source.slice(fixedElementNode.range[0], fixedElementNode.range[1] + 1);
            const firstOperation = firstOpNode.operator + " " + source.slice(firstOpNode.right.range[0], firstOpNode.right.range[1] + 1);
            const secondOperation = node.operator + " " + source.slice(secondOpNode.range[0], secondOpNode.range[1] + 1);
            let replacement = fixedElement + " " + secondOperation + " " + firstOperation;
            pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "PLR"));
        }

        /**
         * Switch order of operations associated to the right
         * original: a * (b / c), replacement: a / (c * b)
         * original: a / (b * c), replacement: a * (c / b)
         * @param {*} visit the visitor
         * @param {Object} node the binary expression node
         * @param {Object} fixedElementNode the fixed element (a)
         * @param {Object} firstOpNode the first operation node ( operator b )
         * @param {Object} secondOpNode the second operation node ( operator c )
         */
        function mutateRightAssociative(visit, node, fixedElementNode, firstOpNode, secondOpNode) {
            const start = node.range[0];
            const end = node.range[1] + 1;
            const startLine = node.loc.start.line;
            const endLine = node.loc.end.line;
            const functionName = contextParser.getFunctionName(visit,startLine,endLine);
            const original = source.slice(start, end);
            const fixedElement = source.slice(fixedElementNode.range[0], fixedElementNode.range[1] + 1);
            const firstOperation = node.operator + " " + source.slice(firstOpNode.range[0], firstOpNode.range[1] + 1);
            const secondOperation = secondOpNode.operator + " " + source.slice(secondOpNode.right.range[0], secondOpNode.right.range[1] + 1);
            let replacement = fixedElement + " " + secondOperation + " " + firstOperation;
            pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "PLR"));
        }

        /**
         * Add a mutation to the mutations list
         * @param {Object} mutation the mutation object
         */
        function pushMutation(mutation) {
            if (!mutations.find(m => m.id === mutation.id)) {
                mutations.push(mutation);
            }
        }

        return mutations;
    }
}


module.exports = PLROperator
