// External modules
const appRoot = require('app-root-path');
const chalk = require('chalk')
const fs = require("fs");
const path = require("path");
const parser = require('@solidity-parser/parser');
// Internal modules
const utils = require('./utils');
const testingInterface = require("./testingInterface");
//SuMo configuration
const rootDir = utils.win32PathConverter(appRoot.toString());
const sumoCoverageJsonPath = utils.staticConf.sumoCoverageJsonPath;


/**
 * Execute the whole coverage generation process and saves the data inside the "sumo/sumo-coverage.json" file
 * @param {Array<string>} testingFrameworks The list of testing framework(s) used within the SUT
 * @param {string} testDir The path of the tests directory
 * @param {string} contractsDir The path of the contracts directory
 */
function runCoverage(testingFrameworks, contractsUnderMutation, testsToBeRun) {
    try {
        //Intialize the sumo-coverage.json report with contract entries
        let sumoCoverage = initializeSumoCoverageData(contractsUnderMutation);

        for (const framework of testingFrameworks) {

            let filteredTests = utils.getTestsForFramework(framework, testsToBeRun);
            //Get coverage report for whole test suite first
            console.log("Processing " + chalk.underline(framework) + " coverage for all test files... ");

            if (filteredTests.length === 0) {
                console.log("No tests to be evaluated for " + framework + ", coverage skipped.\n");
                continue;
            }


            testingInterface.spawnCoverage(framework, filteredTests)
            sumoCoverage = getSumoCoverage(sumoCoverage, framework);

            //Extract information about each test
            filteredTests.forEach((test) => {
                console.log(
                    "Processing coverage for: " + path.parse(test).dir + "/" + chalk.bold(path.basename(test))
                );
                //Generate the coverage report of a test using a specific framework
                testingInterface.spawnCoverage(framework, [test]);
                sumoCoverage = addCoveringTestFiles(sumoCoverage, framework, test);
            });
        }

        console.log(chalk.yellow("Fixing coverage information..."));
        sumoCoverage = addMissingFields(sumoCoverage, testsToBeRun, testingFrameworks);

        console.log(chalk.yellow("Computing coverage of state variables..."));
        sumoCoverage = getTestsCoveringStateVariables(sumoCoverage);

        //Save coverage data inside a JSON file
        fs.writeFileSync(sumoCoverageJsonPath, JSON.stringify(sumoCoverage), "utf-8");

        console.log(chalk.green("Coverage report successfully generated! You can find it in " + sumoCoverageJsonPath));
        return sumoCoverage;
    } catch (error) {
        console.log(error);
        if (fs.existsSync(sumoCoverageJsonPath)) { fs.unlinkSync(sumoCoverageJsonPath); }
        console.log(chalk.red("Coverage process failed: please try again!"));
    }
}

/**
 * Initialize sumoCoverage data with all the contracts to be mutated
 * @param {*} contractsUnderMutation 
 * @returns initialized sumoCoverage array
 */
function initializeSumoCoverageData(contractsUnderMutation) {
    const contractsPath = contractsUnderMutation;
    const sumoCoverage = [];

    contractsPath.forEach((path) => {
        path = path.replace((rootDir + '/'), "");
        if (path.endsWith(".sol")) {
            var contract = new Object();
            contract.contract = path;
            contract.functions = [];
            contract.state_variables = [];
            sumoCoverage.push(contract);
        }
    });

    return sumoCoverage;
}

/**
 * Builds preliminary "sumo/sumo-coverage.json" data by running coverage on the whole test suite
 * @param {Object} sumoCoverage - initialized "sumo-coverage.json" with empty contract entries
 * @param {string} framework - the testing framework to be used for the coverage collection process
 * @returns {Object} the sumo-coverage.json initialized with the project's contract entries
 */
function getSumoCoverage(sumoCoverage, framework) {
    let coverageData = "";
    switch (framework) {
        case "hardhat": coverageData = fs.readFileSync(rootDir + "/coverage.json", "utf8"); return getSolidityCoverage(sumoCoverage, coverageData);
        case "forge": coverageData = fs.readFileSync(rootDir + "/lcov.info", "utf8"); return getForgeCoverage(sumoCoverage, coverageData);
        case "brownie": coverageData = fs.readFileSync(rootDir + "/reports/coverage.json", "utf8"); return getBrownieCoverage(sumoCoverage, coverageData);
        default: {
            throw new Error("Error: The selected testing framework(s) is not valid.");
        }
    }
}

/**
 * Starts the coverage process with a specific test and analyzes the resulting coverage data.
 * It extends the "sumo-coverage.json" by adding test to all the functions it actually covers
 * @param {Object} sumoCoverage - initialized "sumo-coverage.json" with empty contract entries
 * @param {string} framework - the testing framework to be used for the coverage collection process
 * @param {string} test - the test file to collect coverage data for
 * @returns {Object} the sumo-coverage.json extended with coverage data for <test>
 */
function addCoveringTestFiles(sumoCoverage, framework, test) {
    let coverageData, testCovContracts;

    switch (framework) {
        case "hardhat":
            coverageData = fs.readFileSync(rootDir + "/coverage.json", "utf8");
            testCovContracts = getSolidityCoverageByTest(coverageData, sumoCoverage, test);
            break;
        case "forge":
            coverageData = fs.readFileSync(rootDir + "/lcov.info", "utf-8");
            testCovContracts = getForgeCoverageByTest(coverageData, sumoCoverage, test);
            break;
        case "brownie":
            coverageData = fs.readFileSync(rootDir + "/reports/coverage.json", "utf8");
            testCovContracts = getBrownieCoverageByTest(coverageData, sumoCoverage, test);
            break;
        default:
            throw new Error("Error: The selected testing framework is not valid.")
    }

    return testCovContracts
}

/**
 * Returns the list of test files covering a given mutation within a contract.
 *
 * @param {string} file - The name of the mutated contract.
 * @param {number} startLine - The line number where the mutation starts.
 * @param {number} endLine - The line number where the mutation ends.
 * @param {string[]} frameworks - The testing frameworks to be used.
 * @param {string[]} testsToBeRun - The list of all test files to be run.
 * @returns {string[]} - The list of test files covering the mutation, or testsToBeRun if undefined.
 */
function getTestFilesCoveringMutation(file, startLine, endLine, frameworks, testsToBeRun) {
    let coveringTests = new Set([]);
    let contractCoverageData;

    // Check if the coverage report exists, throw an error if not found
    if (!fs.existsSync(sumoCoverageJsonPath)) {
        throw new Error(chalk.yellow("Coverage report: ") + sumoCoverageJsonPath + chalk.yellow(" not found!"));
    } else {
        // Read and parse coverage report, find contract data
        contractCoverageData = JSON
            .parse(fs.readFileSync(sumoCoverageJsonPath, "utf8"))
            .find(con => rootDir + "/" + con.contract === file);

        // Return all test files if no contract information is found
        if (contractCoverageData === undefined) { return testsToBeRun }
    }

    // Loop through each function in the contract coverage data to check if the mutation is within a function
    for (const fun of contractCoverageData.functions) {
        if ((startLine >= fun.start && endLine <= fun.end) || fun.start === -1) {
            if (fun.coverageCount > 0 || fun.covered) {
                // Solidity-coverage check for whole contract test files
                if (frameworks.includes("hardhat")) {
                    let allContractFunction = contractCoverageData.functions.find(obj => obj.name === "__allContract__");

                    if (allContractFunction?.tests.length > 0) {
                        allContractFunction.tests.forEach(test => {
                            coveringTests.add(test);
                        });
                    }
                }

                // Check if the specific statement where the mutation is applied is covered by tests
                let s = fun.statements.find(s => s.start === startLine);
                if (s !== undefined && (s.coverageCount === 0 || s.covered === false)) {
                    return Array.from(coveringTests); // Return the empty set
                }

                // Add covering tests to set
                fun.tests.forEach(test => {
                    coveringTests.add(test);
                });
                return Array.from(coveringTests); // Return the list of covering tests
            } else {
                return Array.from(coveringTests); // Function is not covered, return the empty set
            }
        }
    }

    // Check if mutation is on a state variable
    contractCoverageData.state_variables.forEach(svar => {
        if (startLine >= svar.start && endLine <= svar.end) {
            svar.tests.forEach(test => {
                coveringTests.add(test);
            });
        }
    });
    return Array.from(coveringTests); // Return the list of covering tests
}



/**************************************************
 * PROCESS SOLIDITY-COVERAGE REPORT
 ***************************************************/

/**
 * Extracts the statement coverage information from the complete solidity-coverage.json report.
 * Then, it extends each function in the sumo coverage report with it.
 * @param {*} sumoCoverage the sumoCoverage data to be enhanced with statement info
 * @param {*} coverageData the solidity-coverage data
 * @returns sumoCoverage enhanced with statement coverage information for each function
 */
function getSolidityCoverage(sumoCoverage, coverageData) {
    const jsonCov = JSON.parse(coverageData);

    // Iterate through each contract file in the coverage data
    for (const filePath in jsonCov) {
        if (Object.prototype.hasOwnProperty.call(jsonCov, filePath)) {

            const fileCoverage = jsonCov[filePath];
            const functions = [];
            // Check f field <function_id>, <coverage_count>
            const functionEntries = Object.entries(fileCoverage.f || {});

            // Check if there are functions in the contract's coverage data   
            if (functionEntries.length > 0) {

                // Process each function if coverage data exists
                functionEntries.forEach(([fun, funCovCount]) => {
                    // Get loc and name from "fnMap"
                    const { loc, name } = fileCoverage.fnMap[fun];
                    const functionStartLine = loc.start.line;
                    const functionEndLine = loc.end.line;
                    const statements = extractSolidityCoverageStatements(fileCoverage, functionStartLine, functionEndLine);

                    // Check if the function already exists in sumoCoverage
                    const existingFunctionIndex = sumoCoverage.findIndex(contract => contract.contract === utils.win32PathConverter(filePath));

                    if (existingFunctionIndex !== -1) {
                        const existingFunction = sumoCoverage[existingFunctionIndex].functions.find(func => func.name === name);
                        if (existingFunction) {
                            // Function already exists, update its covered and coverageCount fields
                            existingFunction.coverageCount += funCovCount;
                            if (funCovCount > 0 && !existingFunction.covered) { existingFunction.covered = true; }

                            existingFunction.statements.forEach(existingStatement => {
                                const newStatement = statements.find(stmt =>
                                    stmt.start === existingStatement.start
                                );
                                if (newStatement) {
                                    existingStatement.coverageCount += newStatement.coverageCount;
                                    if (newStatement.coverageCount > 0 && !existingStatement.covered) { existingStatement.covered = true; }
                                }
                            });
                        } else {
                            // Function doesn't exist, add it to existing contract
                            sumoCoverage[existingFunctionIndex].functions.push({
                                name: name,
                                start: functionStartLine,
                                end: functionEndLine,
                                coverageCount: funCovCount,
                                covered: funCovCount > 0 ? true : false,
                                statements: statements,
                                tests: []
                            });
                        }
                    } else {
                        // If contract doesn't exist, add a new entry
                        functions.push({
                            name: name,
                            start: functionStartLine,
                            end: functionEndLine,
                            coverageCount: funCovCount,
                            covered: funCovCount > 0 ? true : false,
                            statements: statements,
                            tests: []
                        });
                    }
                });
            }
            // If no functions are present (e.g., interfaces), add a placeholder "__allContract__" function
            else {
                functions.push({
                    name: "__allContract__",
                    start: -1,
                    end: -1,
                    tests: []
                });
            }

            // If contract already exists, do not add it again
            const existingContractIndex = sumoCoverage.findIndex(contract => contract.contract === utils.win32PathConverter(filePath));
            if (existingContractIndex === -1) {
                // Add contract coverage details to the contracts array
                sumoCoverage.push({
                    contract: utils.win32PathConverter(filePath),
                    functions: functions,
                });
            }
        }
    }
    return sumoCoverage;
}

/**
 * Process the output of Solidity-coverage report. 
 * It captures information about contract functions covered during testing.
 * @param {*} coverageData the coverage.json report generated by solidity-coverage on <test>
 * @param {*} sumoCoverage the data extracted from the coverage.json report generated by solidity-coverage on the whole test suite
 * @param {*} test the test file that produced the coverageData  
 * @returns the list of contracts with the relative function info
 */
function getSolidityCoverageByTest(coverageData, sumoCoverage, test) {
    const jsonCov = JSON.parse(coverageData);

    /**
     * Native Solidity tests are not supported by solidity-coverage!
     * The test is added to the __allContract__ object to avoid imprecisions. 
     * The __allContract__ object lists all the tests that must always be run on the whole contract
     */
    if (test.endsWith(".sol")) {
        sumoCoverage.forEach(contract => {
            let allContractFunction = contract.functions.find(obj => obj.name === "__allContract__");

            if (!allContractFunction) {
                contract.functions.push({
                    name: "__allContract__",
                    start: -1,
                    end: -1,
                    tests: [test]
                });
            } else {
                allContractFunction.tests.push(test);
            }
        });
    } else {
        // Iterate through each contract file in the coverage data
        for (const filePath in jsonCov) {
            if (Object.prototype.hasOwnProperty.call(jsonCov, filePath)) {

                const fileCoverage = jsonCov[filePath];
                //Check f field <function_id>, <coverage_count>
                const functionEntries = Object.entries(fileCoverage.f || {});

                // Check if there are functions in the contract's coverage data   
                if (functionEntries.length > 0) {

                    // Check if this function is covered by the test, if yes add it
                    functionEntries.forEach(([funcID, funCovCount]) => {
                        if (funCovCount > 0) {
                            let contractToExtend = sumoCoverage.find(c => c.contract === utils.win32PathConverter(filePath));

                            if (contractToExtend !== undefined) {
                                const functionName = fileCoverage.fnMap[funcID].name;

                                let functionToExtend = contractToExtend.functions.find(f => f.name === functionName);
                                if (functionToExtend !== undefined) {
                                    functionToExtend.tests.push(test)
                                }
                            }
                        }
                    });
                }
            }
        }
    }
    return sumoCoverage;
}


/**
* Extract the statement coverage info within a function's range 
 * @param {*} fileCoverage the solidity-coverage data for the contract containing the function
 * @param {*} functionStartLine the function's start line
 * @param {*} functionEndLine the function's end line * 
 * @returns A statements array with coverage data for the input function
 */
function extractSolidityCoverageStatements(fileCoverage, functionStartLine, functionEndLine) {
    const statements = [];

    for (const statementId in fileCoverage.statementMap) {
        if (!fileCoverage.statementMap.hasOwnProperty(statementId)) continue;

        const statementLocation = fileCoverage.statementMap[statementId];
        const statementStartLine = statementLocation.start.line;
        const statementEndLine = statementLocation.end.line;

        if (statementStartLine >= functionStartLine && statementEndLine <= functionEndLine) {
            const statementCoverageCount = fileCoverage.s[statementId] || 0;

            statements.push({
                start: statementStartLine,
                end: statementEndLine,
                coverageCount: statementCoverageCount,
                covered: statementCoverageCount > 0 ? true : false
            });
        }
    }
    return statements;
}

/**************************************************
 * PROCESS FORGE-COVERAGE REPORT
 ***************************************************/

/**
 * Process forge coverage report related to the whole test suite to extract function and statement information
 * @param {*} sumoCoverage the data extracted from the coverage.json report generated by solidity-coverage on the whole test suite
 * @param {*} coverageString the report generated by forge-coverage on the whole test suite
 * @returns processed coverage info to be completed with function-covering test
 */
function getForgeCoverage(sumoCoverage, coverageString) {
    const records = coverageString.split("end_of_record");

    for (let record of records) {
        let count = 0;
        if (record.trim() === "") continue;
        const lines = record.trim().split("\n");
        const coverage = {
            contract: "",
            functions: []
        };

        for (let line of lines) {
            let [key, value] = line.split(":");
            key = key.trim();
            const valueArray = value.trim().split(",");

            //FN: Function Name - Specifies the function name and its start line number.
            // The format is FN:<contract_name.function_name>,<line_number>.  
            if (key === "FN") {
                coverage.functions.push({
                    name: valueArray[1].split('.')[1], //function name
                    start: Number(valueArray[0]), //function start line
                    end: null, //function end line (not specified in lcov)
                    coverageCount: null, //the numbe of times the function was covered during tests
                    covered: false, //if the function is covered or not
                    tests: [], // Placeholder for tests covering this function
                    statements: [] // Placeholder for statements of this function                    
                });
                count++;
            }
            //FNDA: Function Data - Indicates the number of times the function was called during testing.
            // The format is FNDA:<execution_count>,<contract_name.function_name>.
            else if (key === "FNDA") {
                coverage.functions[count - 1].coverageCount = Number(valueArray[0]);
                coverage.functions[count - 1].covered = Number(valueArray[0]) > 0 ? true : false;
            }
            //DA: Line Data - Shows the number of times each line was executed during testing.
            // The format is DA:<line_number>,<execution_count>.
            else if (key === "DA") {
                const statementStart = Number(valueArray[0]);
                const statementCount = Number(valueArray[1]);
                coverage.functions[count - 1].statements.push({
                    start: statementStart,
                    end: null,
                    coverageCount: statementCount,
                    covered: statementCount > 0 ? true : false
                });
            }
            //SF: Source File - Indicates the name of the source file being analyzed (e.g., contracts/ContractName.sol)
            else if (key === "SF") {
                coverage.contract = valueArray[0];
            }
        }
        //Retrieve and set the end line of each function (not provided by lcov)
        const solidityCode = fs.readFileSync(rootDir + '/' + coverage.contract, "utf8");
        const ast = parser.parse(solidityCode, { loc: true });
        parser.visit(ast, {
            FunctionDefinition: function (node) {
                coverage.functions.forEach(fun => {
                    if (fun.start === node.loc.start.line) {
                        fun.end = node.loc.end.line;
                    }
                });
            }
        });

        const existingContractIndex = sumoCoverage.findIndex(contract => contract.contract === coverage.contract);

        if (existingContractIndex !== -1) {
            const existingFunctions = sumoCoverage[existingContractIndex].functions;

            coverage.functions.forEach(newFunction => {
                const existingFunctionIndex = existingFunctions.findIndex(func =>
                    func.name === newFunction.name && func.start === newFunction.start
                );

                if (existingFunctionIndex !== -1) {
                    const existingFunction = existingFunctions[existingFunctionIndex];

                    existingFunction.coverageCount = newFunction.coverageCount || existingFunction.coverageCount;
                    existingFunction.covered = newFunction.covered || existingFunction.covered;

                    newFunction.statements.forEach(newStatement => {
                        const existingStatementIndex = existingFunction.statements.findIndex(stmt =>
                            stmt.start === newStatement.start
                        );

                        if (existingStatementIndex !== -1) {
                            existingFunction.statements[existingStatementIndex].coverageCount += newStatement.coverageCount;
                            if (newStatement.coverageCount > 0 && !existingFunction.statements[existingStatementIndex].covered) {
                                existingFunction.statements[existingStatementIndex].covered = true;
                            }

                        } else {
                            existingFunction.statements.push(newStatement);
                        }
                    });
                } else {
                    existingFunctions.push(newFunction);
                }
            });
        } else {
            sumoCoverage.push(coverage);
        }
    }
    return sumoCoverage;
}


/**
 * Process the output of forge coverage for a specific test file.
 * It allows to understand if a test covers a specific function through the FNDA value
 * @param {*} coverageData the lcov.info report generated by Forge on <test>
 * @param {*} sumoCoverage the data extracted from the coverage.json report generated by solidity-coverage on the whole test suite
 * @param {*} test the test file that produced the coverageData  
 * @returns the processed coverage information
 */
function getForgeCoverageByTest(coverageString, sumoCoverage, test) {
    const records = coverageString.split("end_of_record");

    for (let record of records) {
        if (record.trim() === "") continue;
        const lines = record.trim().split("\n");

        let contractName = null;
        let functionName = null;
        let coverageCount = null;
        let covered = null;

        for (let line of lines) {

            let [key, value] = line.split(":");
            key = key.trim();
            const valueArray = value.trim().split(",");

            if (key === "SF") {
                contractName = valueArray[0];
                //reset function name and coverage count 
                functionName = null;
                coverageCount = null;
                covered = null;
            }
            else if (key === "FN") {
                functionName = valueArray[1].split('.')[1];
                //reset coverage count 
                coverageCount = null;
                covered = null;
            }
            else if (key === "FNDA") {
                coverageCount = Number(valueArray[0]);
                covered = coverageCount > 0 ? true : false;

                if (contractName !== null && functionName !== null && coverageCount !== null && coverageCount > 0) {

                    let contractToExtend = sumoCoverage.find(c => c.contract === contractName);

                    if (contractToExtend !== undefined) {
                        let functionToExtend = contractToExtend.functions.find(f => f.name === functionName);
                        if (functionToExtend !== undefined) {
                            functionToExtend.tests.push(test)
                        }
                    }
                }
            }
        }
    }
    return sumoCoverage;
}

/**************************************************
 * PROCESS BROWNIE-COVERAGE REPORT
 ***************************************************

/**
 * Process brownie coverage report related to the whole test suite to extract function and statement information.
 * @param {Object[]} sumoCoverage - The initialized sumo-coverage.json.
 * @param {string} coverageData - The report generated by brownie coverage on the whole test suite.
 * @returns {Object[]} - sumo-coverage report to be completed with function-covering test.
 */
function getBrownieCoverage(sumoCoverage, coverageData) {

    const brownieCoverageJson = JSON.parse(coverageData);
    //Use brownie build data to build associations contract-ID-path (e.g., '1': 'contracts/.../ContractName.sol',)
    const contractInfo = getBrownieContractsInfoFromBuild();

    for (const contractID in contractInfo) {
        let sumoCoverageEntry = sumoCoverage.find(obj => obj.contract === contractInfo[contractID])

        if (sumoCoverageEntry !== undefined) {
            //Check statements coverage info in the brownie coverage report
            for (let statement in brownieCoverageJson.highlights.statements) {

                // Check if a contract is included inside the report
                if (brownieCoverageJson.highlights.statements[statement].hasOwnProperty(contractID)) {

                    try {
                        //Read contract file text
                        const contractFileText = fs.readFileSync(contractInfo[contractID], "utf8");

                        //Analyze each statement related for the current contract
                        brownieCoverageJson.highlights.statements[statement][contractID].forEach(cnt => {

                            let statement = {
                                start: getLineNumberFromOffset(contractFileText, cnt[0]),      //cnt[0] is start character position of statement
                                end: getLineNumberFromOffset(contractFileText, cnt[1]), // cnt[1] is end character position of statement
                                coverageCount: null, //coverageCount not available for Brownie
                                covered: cnt[2] === 'green' ? true : false
                            };

                            //Find function to which the statement belongs
                            const enclosingFunction = getBrownieFunction(contractInfo[contractID], contractFileText, statement.start);
                            //If the enclosing function already exists in the sumo-coverage, we add the statement to it and
                            //update its covered property if necessary
                            let existingFunction = sumoCoverageEntry.functions.find(f => f.name === enclosingFunction.name)
                            if (existingFunction !== undefined) {
                                existingFunction.statements.push(statement);
                                if (statement.covered && !existingFunction.covered) existingFunction.covered = true;
                            }
                            //If the enclosing function does not already exists in the sumo-coverage, add it
                            else {
                                enclosingFunction.statements.push(statement);
                                if (statement.covered && !enclosingFunction.covered) enclosingFunction.covered = true;
                                sumoCoverageEntry.functions.push(enclosingFunction);
                            }
                        })
                    }
                    catch (readFileError) {
                        throw new Error(`Error reading file ${contractFilePath}: ${readFileError.message}`);
                    }
                }
            }
        }
    }
    return sumoCoverage;
}


/**
 * Process the output of brownie coverage for a specific test file.
 * It allows to understand if a test covers a specific function
 * @param {*} coverageData the lcov.info report generated by Brownie on <test>
 * @param {*} sumoCoverage the data extracted from the coverage.json report generated by brownie on the whole test suite
 * @param {*} test the test file that produced the coverageData  
 * @returns the processed coverage information
 */
function getBrownieCoverageByTest(coverageData, sumoCoverage, test) {
    const brownieCoverageJson = JSON.parse(coverageData);
    //Use brownie build data to build associations contract-ID-path (e.g., '1': 'contracts/.../ContractName.sol',)
    const contractInfo = getBrownieContractsInfoFromBuild();

    for (const contractID in contractInfo) {
        let sumoCoverageEntry = sumoCoverage.find(obj => obj.contract === contractInfo[contractID]);

        if (sumoCoverageEntry !== undefined) {
            //Check statements coverage info in the brownie coverage report
            //Brownie does not specify if a function is covered, only its statements
            for (let statement in brownieCoverageJson.highlights.statements) {

                // Check if a contract is included inside the report
                if (brownieCoverageJson.highlights.statements[statement].hasOwnProperty(contractID)) {

                    try {
                        //Read contract file text
                        const contractFileText = fs.readFileSync(contractInfo[contractID], "utf8");

                        //Analyze each statement related for the current contract
                        brownieCoverageJson.highlights.statements[statement][contractID].forEach(cnt => {
                            //If the statement is covered, add test to its function
                            if (cnt[2] === 'green') {
                                const statementStartLine = getLineNumberFromOffset(contractFileText, cnt[0]);
                                const enclosingFunction = getBrownieFunction(contractInfo[contractID], contractFileText, statementStartLine);
                                //If the enclosing function already exists in the sumo-coverage, add the test file to it
                                let existingFunction = sumoCoverageEntry.functions.find(f => f.name === enclosingFunction.name)
                                if (existingFunction !== undefined && !existingFunction.tests.includes(test)) {
                                    existingFunction.tests.push(test);
                                }
                            }
                        })
                    }
                    catch (readFileError) {
                        throw new Error(`Error reading file ${contractFilePath}: ${readFileError.message}`);
                    }
                }
            }
        }
    }

    return sumoCoverage;
}

/**
 * Retrieves contract information from JSON files in the brownie build directory.
 * @param {string} basePath - The base path of the directory containing JSON files (usually build/contracts).
 * @returns {Object} - Merged object containing the association between ID and contracts source paths.
 */
function getBrownieContractsInfoFromBuild() {
    let basePath = 'build/contracts';
    try {
        const files = fs.readdirSync(basePath);
        const jsonStructure = [];

        files.forEach((file) => {
            const filePath = path.join(basePath, file); // Constructs file path
            const stat = fs.statSync(filePath); // Gets file information

            if (stat.isFile()) { // Checks if it's a file
                try {
                    const json = JSON.parse(fs.readFileSync(filePath, 'utf8')); // Reads and parses JSON
                    jsonStructure.push(json.allSourcePaths); // Collects contract source paths
                } catch (jsonParseError) {
                    throw new Error(`Error parsing JSON file ${filePath}: ${jsonParseError.message}`)
                }
            }
        });

        const mergedObject = {};

        // Merges collected contract source paths into a single object
        jsonStructure.forEach(obj => {
            for (const key in obj) {
                if (!(key in mergedObject)) {
                    mergedObject[key] = obj[key];
                }
            }
        });

        return mergedObject; // Returns the merged object with contract source paths
    } catch (readDirError) {
        throw new Error(`Error reading directory ${basePath}: ${readDirError.message}`)
    }
}


/**
 * Given a character position, returns the corresponding line of code.
 * @param {string} contractCode - The entire code string.
 * @param {number} position - The character position.
 * @returns {number} - The corresponding line number.
 */
function getLineNumberFromOffset(contractCode, position) {
    // Replace Windows and old macOS end-of-line characters with newline
    let text = contractCode.replaceAll("\r\n", "\n").replaceAll("\r", "\n");

    // Get lines of code based on the given position
    const lines = text.substr(0, position).split('\n');
    return lines.length;
}


/**
 * Given an input contract and a line of code, returns information about the function that contains that line.
 * @param {string} contractName - The name of the contract.
 * @param {string} contractCode - The code of the contract.
 * @param {number} targetLine - The line number.
 * @returns {object} - Information about the function containing the target line.
 */
function getBrownieFunction(contractName, contractCode, targetLine) {
    const ast = parser.parse(contractCode, { loc: true });

    let functionInfo = {
        name: null,
        start: null,
        end: null,
        statements: [],
        tests: [],
        coverageCount: null, //coveragecount not available for Brownie
        covered: false
    };

    ast.children.forEach(element => {
        if (element.type === "ContractDefinition" && contractName.toLowerCase().includes(element.name.toLowerCase())) {
            element.subNodes.forEach(node => {
                if (node.type === "FunctionDefinition" && (targetLine >= node.loc.start.line && targetLine <= node.loc.end.line)) {
                    functionInfo.name = node.name;
                    functionInfo.start = node.loc.start.line;
                    functionInfo.end = node.loc.end.line;

                    if (node.isConstructor) { functionInfo.name = "constructor"; }
                    if (node.isReceiveEther) { functionInfo.name = "receive"; }
                    if (node.isFallback) { functionInfo.name = "fallback"; }
                }
            });
        }
    });

    return functionInfo;
}

/**************************************************
 * COVERAGE-EXTRACTION UTILITIES
 ***************************************************

/**
 * For each contract add all state variables inside report and for Forge & Brownie add constructor (if present inside contract) and modifier functions
 * @param {*} sumoCoverage the sumo coverage data
 * @param {*} testsPath the list of all test file paths
 * @param {*} framework the list of testing framework(s) to be used
 * @returns 
 */
function addMissingFields(sumoCoverage, testsPath, testingFrameworks) {
    sumoCoverage.forEach((con) => {

        //Parse the smart contract
        const solidityCode = fs.readFileSync(rootDir + '/' + con.contract, "utf8");
        const ast = parser.parse(solidityCode, { loc: true })
        con.state_variables = [];

        //Add state variable coverage info to each contract
        parser.visit(ast, {
            StateVariableDeclaration: function (node) {
                node.variables.forEach(vari => {
                    con.state_variables.push({
                        name: vari.name,
                        start: vari.loc.start.line,
                        end: vari.loc.end.line,
                        tests: [],
                        coverageCount: 0,
                        covered: false
                    });
                });
            },
            EnumDefinition: function (node) {
                con.state_variables.push({
                    name: node.name,
                    start: node.loc.start.line,
                    end: node.loc.end.line,
                    tests: [],
                    coverageCount: 0,
                    covered: false
                });
            },
            StructDefinition: function (node) {
                con.state_variables.push({
                    name: node.name,
                    start: node.loc.start.line,
                    end: node.loc.end.line,
                    tests: [],
                    coverageCount: 0,
                    covered: false
                });
            }
        })
        /** 
         * Brownie and Forge coverage reports do not provide info about Constructor
         * and Modifier functions. We add them to the sumoCoverage report
         * with all the tests to be run, but coverageCount = null
         */
        if ((testingFrameworks.includes("forge") || testingFrameworks.includes("forge")) &&
            (!testingFrameworks.includes("hardhat"))) {
            parser.visit(ast, {
                FunctionDefinition: function (node) {
                    if (node.isConstructor) {
                        con.functions.push({
                            name: "constructor",
                            start: node.loc.start.line,
                            end: node.loc.end.line,
                            coverageCount: null,
                            tests: testsPath,
                            statements: []
                        });
                    }
                },
                ModifierDefinition: function (node) {
                    con.functions.push({
                        name: node.name,
                        start: node.loc.start.line,
                        end: node.loc.end.line,
                        coverageCount: null,
                        tests: testsPath,
                        statements: []
                    });
                }
            })
        }
    });

    return sumoCoverage;
}


//Obtain coverage of state variables through the functions that call them in each contract
function getTestsCoveringStateVariables(sumoCoverage) {
    sumoCoverage.forEach((con) => {
        const solidityCode = fs.readFileSync(rootDir + '/' + con.contract, "utf8");

        //Parse the smart contract
        const ast = parser.parse(solidityCode, { loc: true });

        //Copy function tests inside state variable tests
        parser.visit(ast, {
            Identifier: function (node) {
                con.functions.forEach(fun => {
                    if (fun.coverageCount > 0) {
                        if ((node.loc.start.line >= fun.start && node.loc.end.line <= fun.end) || fun.start === -1) {
                            var stateV = con.state_variables.find(obj => obj.name === node.name);
                            if (stateV !== undefined) {
                                const filteredTests = fun.tests.filter((element) => !stateV.tests.includes(element));
                                stateV.tests = stateV.tests.concat(filteredTests);
                                if (fun.coverageCount > 0) {
                                    //Approximated coverageCount for state variable. We just need to know if it is covered or not
                                    stateV.coverageCount += fun.coverageCount;
                                    stateV.covered = true;
                                }
                            }
                        }
                    }
                });
            },
            AssemblyCall: function (node) {
                con.functions.forEach(fun => {
                    if (fun.coverageCount > 0) {
                        if ((node.loc.start.line >= fun.start && node.loc.end.line <= fun.end) || fun.start === -1) {
                            var stateV = con.state_variables.find(obj => obj.name === node.functionName);
                            if (stateV !== undefined) {
                                const filteredTests = fun.tests.filter((element) => !stateV.tests.includes(element));
                                stateV.tests = stateV.tests.concat(filteredTests);
                                if (fun.coverageCount > 0) {
                                    //Approximated coverageCount for state variable
                                    stateV.coverageCount += fun.coverageCount;
                                    stateV.covered = true;
                                }
                            }
                        }
                    }
                });
            }
        });
    });

    //Search in other contracts if a contract is imported and update the tests to be run
    sumoCoverage.forEach((con) => { sumoCoverage = findContractImport(sumoCoverage, con); });

    return sumoCoverage;
}

//Search in other contracts if a contract is imported and update the tests to be run for state variables
function findContractImport(sumoCoverage, contract) {
    sumoCoverage.forEach((con) => {
        const solidityCode = fs.readFileSync(rootDir + '/' + con.contract, "utf8");

        //Parse the smart contract
        const ast = parser.parse(solidityCode, { loc: true });

        //State variabiles references
        parser.visit(ast, {
            ImportDirective: function (node) {
                if (node.path.endsWith(contract.contract.split('/').pop())) {
                    //take the contract where check the state variables
                    var selectedContract = sumoCoverage.find(obj => obj.contract === contract.contract);
                    parser.visit(ast, {
                        MemberAccess: function (node) {
                            selectedContract.state_variables.forEach(svar => {
                                if (node.memberName === svar.name) {
                                    con.functions.forEach(fun => {
                                        if ((node.loc.start.line >= fun.start && node.loc.end.line <= fun.end) || fun.start === -1) {
                                            const filteredTests = fun.tests.filter((element) => !svar.tests.includes(element));
                                            svar.tests = svar.tests.concat(filteredTests);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            }
        });

        //Struct references
        parser.visit(ast, {
            ImportDirective: function (node) {
                if (node.path.endsWith(contract.contract.split('/').pop())) {
                    //take the contract where check the state variables
                    var selectedContract = sumoCoverage.find(obj => obj.contract === contract.contract);

                    parser.visit(ast, {
                        VariableDeclaration: function (v) {
                            if (v.typeName.type === "UserDefinedTypeName") {
                                selectedContract.state_variables.forEach(svar => {
                                    if (v.typeName.namePath === svar.name) {
                                        // if state variable I copy tests from it otherwise I take location and look for function at that location and copy tests
                                        var testsToImport;
                                        if (v.isStateVar) {
                                            testsToImport = con.state_variables.find(obj => obj.name === v.name);
                                        } else {
                                            testsToImport = con.functions.find(fun => (v.loc.start.line >= fun.start && v.loc.end.line <= fun.end) || fun.start === -1);
                                        }
                                        if (testsToImport !== undefined) {
                                            const filteredTests = testsToImport.tests.filter((element) => !svar.tests.includes(element));
                                            svar.tests = svar.tests.concat(filteredTests);
                                        }
                                    }
                                })
                            }
                        }
                    });
                }
            }
        });
    });

    return sumoCoverage;
}

module.exports = {
    runCoverage: runCoverage,
    getTestFilesCoveringMutation: getTestFilesCoveringMutation
};