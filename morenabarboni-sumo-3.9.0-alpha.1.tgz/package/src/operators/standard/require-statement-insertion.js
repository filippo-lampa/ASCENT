/* DISABLED DUE TO HIGH FALSE POSITIVES GENERATION*/
const Mutation = require("../../mutation");
const parser = require('@solidity-parser/parser');

class RSIOperator {
  constructor() {
    this.ID = "RSI";
    this.name = "require-statement-insertion";
  }
  getMutations(file, source, visit) {
    const mutations = [];
    let allFunctionsInfo = [];
    let allRequires = []; //All the require statement nodes in the contract
    let stateVariables = []; //All the state variables nodes in the contract

    /**
     *  Stores all the state variable nodes into "stateVariables"
     */
    visit({
      StateVariableDeclaration: (node) => {
        if (node.variables.length === 1) {
          stateVariables.push(node.variables[0].name);
        }
      }
    });

    /**
      * Visits each function definition and collect the relative information
      */
    visit({
      FunctionDefinition: (fNode) => {
        if (fNode.body && fNode.name && fNode.name !== "initialize" && !fNode.isConstructor) {
          let functionInfo = {};
          functionInfo.function = fNode;
          let fRequireConditions = []; // require statements used within this function (Condition only)
          let fIdentifiers = []; //variable identifiers declared or used within the current function


          //redefine AST to only visit the sliced function
          const fStart = fNode.range[0];
          const fEnd = fNode.range[1] + 1;
          const fStartLine = fNode.loc.start.line;
          const fSource = source.slice(fStart, fEnd);
          const ast = parser.parse(fSource, { range: true, loc: true });
          const visit = parser.visit.bind(parser, ast);

          //Extract and store all function parameter names
          if (fNode.parameters.length > 0) {
            fNode.parameters.forEach(p => {
              fIdentifiers.push(p.name);
            });
          }
          //Extract and store all the require statements used within the function
          visit({
            FunctionCall: (node) => {
              if (node.expression.name === "require") {
                let requireNode = adjustRangeLoc(node, fStart, fStartLine);
                let adjustedRequireCondition = adjustRangeLoc(requireNode.arguments[0], fStart, fStartLine);
                //Save in require pool
                if (allRequires.find(r => extractRequireConditionString(r.arguments[0]) === extractRequireConditionString(adjustedRequireCondition)) === undefined) {
                  requireNode.stateMutability = fNode.stateMutability;
                  allRequires.push(requireNode);
                }
                fRequireConditions.push(adjustedRequireCondition);
              }
            }
          });
          //Extract and store all variable identifiers declared within the function
          /*visit({
             VariableDeclarationStatement: (s) => {
               if (s.variables[0])
                 fIdentifiers.push(s.variables[0].name);
             }
           });*/
          //Extract and store all variable identifiers used within the function
          /*visit({
            ExpressionStatement: (s) => {
              if (s.expression.type === "BinaryOperation" && s.expression.operator === "=") {
                if (s.expression.left.type !== "IndexAccess" && s.expression.left.type !== "MemberAccess" && !fIdentifiers.includes(s.expression.left.name)) {
                  fIdentifiers.concat(extractIdentifiers(s.expression.left));
                }
              }
            }
          });*/
          functionInfo.requires = fRequireConditions;
          functionInfo.identifiers = fIdentifiers.concat(stateVariables);
          allFunctionsInfo.push(functionInfo);
        }
      }
    });

    allFunctionsInfo.forEach(f => {
      findCompatibleRequire(f);
    });

    /**
      * Find a require that could be added to the input function
      * @param {*} functionInfo
      * @returns a possible mutation
      */
    function findCompatibleRequire(functionInfo) {
      //If the function already contains at least one require
      if (functionInfo.requires.length > 0) {
        //Cycle all the possible replacement requires
        for (let i = 0; i < allRequires.length; i++) {
          let canMutate = true;
          //Possible replacement
          const replacementRequire = allRequires[i];

          if ((functionInfo.function.stateMutability === "view" && replacementRequire.stateMutability === "view") || (functionInfo.function.stateMutability !== "pure" && functionInfo.function.stateMutability !== "view")) {
            //Cycle all the requires used within the function        
            for (let j = 0; j < functionInfo.requires.length; j++) {
              const functionRequire = functionInfo.requires[j];
              let replacementRequireCondition = extractRequireConditionString(replacementRequire.arguments[0]);
              let functionRequireCondition = extractRequireConditionString(functionRequire);
              if (functionRequireCondition.includes(replacementRequireCondition)) {
                canMutate = false;
                break;
              }
            }
            //Require might be compatible
            if (canMutate) {
              let replacementRequireParams = extractIdentifiers(replacementRequire);
              let functionIdentifiers = functionInfo.identifiers;
              if (functionIdentifiers.length > 0) {
                for (let k = 0; k < replacementRequireParams.length; k++) {
                  const replacementRequireParam = replacementRequireParams[k];
                  if (!functionIdentifiers.includes(replacementRequireParam)) {
                    canMutate = false;
                    break;
                  }
                }
              }
              if (canMutate) {
                insertRequire(functionInfo.function, replacementRequire);
              }
            }
          }
        }
      }
    }

    /**
     * Extract the identifiers of an expression
     * @param {*} node a  node
     * @returns array of identifiers
     */
    function extractIdentifiers(node) {
      // Array to store the identifiers
      const identifiers = [];

      // Recursive function to traverse child nodes
      function traverse(node) {
        if (node && node.type) {
          if (node.type === 'TupleExpression') {
            // Extract identifiers from tuple elements
            node.components.forEach(component => traverse(component));
          }
          else if (node.type === 'BinaryOperation') {
            traverse(node.left);
            traverse(node.right);
          }
          else if (node.type === 'UnaryOperation') {
            traverse(node.subExpression);
          }
          else if (node.type === 'FunctionCall') {
            // Extract identifiers from function arguments
            node.arguments.forEach(argument => traverse(argument));
          }
          else if (node.type === 'IndexAccess') {
            traverse(node.base);
            traverse(node.index);
          }
          else if (node.type === 'MemberAccess') {
            traverse(node.expression);
          }
          else if (node.type === 'Identifier'
            && node.name !== "msg"
            && node.name !== "tx"
            && node.name !== "block") {
            // Add the identifier to the list
            identifiers.push(node.name);
          }
        }
      }
      // Start traversing the node
      traverse(node);
      return identifiers;
    }

    /**
    * Extract the trimmed condition of a require (message excluded)
    * @param {*} requireNode the require node
    * @param {*} functionNode the function node   *
    * @returns a string representing the require condition
    */
    function extractRequireConditionString(requireNode) {
      const start = requireNode.range[0];
      const end = requireNode.range[1] + 1; //Do not consider message
      const original = source.slice(start, end).replace(/\s/g, "");;
      return original;
    }

    /**
     * When the source of a node is sliced from the whole contract file, its range and loc are
     * relative to the sliced source. This function re-calculates the range-loc of so that
     * the relative mutations can be correctly applied to the contract. To this end it uses
     * information of an enclosing node (e.g., a function) whose source is the whole contract.
     * @param {*} node the node to be adjusted
     * @param {*} rangeOffset the range offset
     * @param {*} locOffset the line of code offset
     * @returns the adjusted node with correct ranges-locs
     */
    function adjustRangeLoc(node, rangeOffset, locOffset) {
      let adjustedNode = node;
      adjustedNode.range[0] += rangeOffset;
      adjustedNode.range[1] += rangeOffset;
      adjustedNode.loc.start.line += locOffset - 1;
      adjustedNode.loc.end.line += locOffset - 1;
      return adjustedNode;
    }

    /**
    * Extract the trimmed condition of a require (message excluded)
    * @param {*} requireNode the require node
    * @param {*} functionNode the function node   *
    * @returns a string representing the require condition
    */
    function insertRequire(functionNode, requireNode) {
      const start = functionNode.body.range[0];
      const end = functionNode.body.range[0] + 1;
      const startLine = functionNode.body.loc.start.line;
      const endLine = functionNode.body.loc.start.line;
      const original = source.slice(start, end); //Start of function body {
      const startR = requireNode.range[0];
      const endR = requireNode.range[1] + 1; //Do not consider message
      const replacement = original + "\n " + source.slice(startR, endR) + ";";
      pushMutation(new Mutation(file, start, end, startLine, endLine, original, replacement, "RSI"));
    }

    //Apply mutations
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        mutations.push(mutation);
      }
    }
    return mutations;
  }
}


module.exports = RSIOperator;
