// External modules
const chalk = require('chalk')
const jsdiff = require('diff')
const fs = require('fs')
const sha1 = require('sha1')
const path = require('path')
// Internal modules
const utils = require('./utils')
//SuMo static configuration
const { mutantsDir, baselineDir } = utils.staticConf;

class Mutation {
  constructor(file, functionName, start, end, startLine, endLine, original, replace, operator, coveringTests = [],  testResults = {}, status = null, testingTime = null, diff = null, id = null) {
    this.file = file
    this.functionName = functionName
    this.start = start
    this.end = end
    this.startLine = startLine
    this.endLine = endLine
    this.original = original
    this.replace = replace
    this.operator = operator
    this.coveringTests = coveringTests
    this.testResults = testResults
    this.status = status
    this.testingTime = testingTime
    this.id = this.hash()
    this.diff = this.diff()
  }

  /**
   * Apply a mutation to its contract
   */
  apply() {
    const original = fs.readFileSync(this.file, 'utf8')
    const mutated = this.applyToString(original)

    fs.writeFileSync(this.file, mutated, 'utf8')
  }

  applyToString(original) {
    return this.splice(original, this.start, this.end - this.start, this.replace)
  }

  baseline() {
    const contractsDir = utils.getContractsDir()
    return baselineDir + "/contracts" + this.file.substr(contractsDir.length)
  }

  /**
   * Get the mutation line number
   * @returns the line number
   */
  getLine() {
    const source = fs.readFileSync(this.baseline(), 'utf8')
    const index = source.indexOf('\n', this.start)
    const lineNumber = source.substring(0, index).split('\n').length

    return lineNumber
  }

  /**
   * Show standard mutation diff
   * @returns normal diff
   */
  diff() {
    const original = fs.readFileSync(this.baseline(), 'utf8')
    const mutated = this.applyToString(original)

    let diff = jsdiff.diffLines(original, mutated)
    const lineNumber = this.getLine()
    const context = 2

    diff = diff
      .filter(part => JSON.stringify(part.added) || JSON.stringify(part.removed))
      .map(function (part) {

        let num
        if (part.removed) {
          num = lineNumber.toString().padStart(4)
          num = (num + ' | ---')
        } else {
          num = ('     | +++')
        }
        return num + (part.value.replace(/\n$/, ''))
      })

    let lines = mutated.split('\n').map((line, i) => {
      const num = (i + 1).toString().padStart(4)
      return (num + ' | ' + line)
    })

    lines.splice(lineNumber - 1, 1, diff[0], diff[1])

    lines = lines.slice(Math.max(0, lineNumber - context - 1), lineNumber + context + 1)

    return lines.join('\n') + '\n'
  }

  /**
  * Show colored mutation diff
  * @returns colored diff
  */
  diffColor() {
    const original = fs.readFileSync(this.baseline(), 'utf8')
    const mutated = this.applyToString(original)

    let diff = jsdiff.diffLines(original, mutated)
    const lineNumber = this.getLine()
    const context = 2

    diff = diff.filter(part => part.added || part.removed)
      .map(part => {
        const color = part.added ? 'green' : part.removed ? 'red' : 'grey'
        const num = part.removed ? chalk.gray(lineNumber.toString().padStart(4) + ' | ') : chalk.gray('     | ')
        return num + chalk[color](part.value.replace(/\n$/, ''))
      })

    let lines = mutated.split('\n')
      .map((line, i) => chalk.gray((i + 1).toString().padStart(4) + ' | ' + line))

    lines.splice(lineNumber - 1, 1, diff[0], diff[1])

    lines = lines.slice(Math.max(0, lineNumber - context - 1), lineNumber + context + 1)

    return lines.join('\n') + '\n'
  }

  /**
  * Gets the mutation file name
  * @returns the name of the mutated contract
  */
  fileName() {
    const lastIndex = this.file.lastIndexOf('/')
    let fileName = this.file.slice(lastIndex + 1)

    return fileName
  }

  hash() {
    const input = [path.basename(this.file), this.start, this.end, this.original, this.replace, this.operator].join(':')
    return "m" + sha1(input).slice(0, 8)
  }

  restore() {
    const baseline = this.baseline()

    console.log('Restoring ' + this.file)

    const original = fs.readFileSync(baseline, 'utf8')
    fs.writeFileSync(this.file, original, 'utf8')
  }

  /**
  * Saves a mutant to file (apply and restore)
  */
  save() {
    const original = fs.readFileSync(this.file, "utf8")
    const mutated = this.applyToString(original)

    var contractName = path.basename(this.file)

    fs.writeFileSync(mutantsDir + "/" + contractName + "-" + this.hash() + ".sol", mutated, function (err) {
      if (err) return console.log(err)
    })

    fs.writeFileSync(this.file, original, "utf8")
  }

  splice(str, start, length, replacement) {
    return str.substring(0, start) + replacement + str.substring(start + length)
  }

  /**
   * Converts the mutation to json
   * @returns the json representation of a mutation
   */
  toJson() {
    var m = new Mutation(this.file, this.functionName, this.start, this.end, this.startLine, this.endLine, this.original, this.replace, this.operator, this.coveringTests, this.testResults, this.status, this.testingTime, this.id)
    return JSON.stringify(m, null, "\t")
  }

  patch() {
    const original = fs.readFileSync(this.baseline(), 'utf8')
    const mutated = this.applyToString(original)

    return jsdiff.createPatch(this.file, original, mutated)
  }
}

module.exports = Mutation