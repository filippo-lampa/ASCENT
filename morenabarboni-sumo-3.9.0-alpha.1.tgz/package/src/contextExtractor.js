/**
* ContextExtractor - This module includes the logic for extracting the relevant file
* context for a mutant. This is mostly used to build a context for test generation purposes
*/
const cfg = require('./cfg');
const utils = require('./utils');
const babel = require('@babel/parser');
const fs = require('fs')
const parser = require('@solidity-parser/parser');
const path = require("path");
const recast = require('recast');
const chalk = require('chalk');

/**
* EXTRACT LLM CONTEXT FOR MUTANTS
*/

/**
* Extends the mutations.json with code context and test setup information for the LLM experiment.
* - The code context requires access to the Surya CFG
* - The test setup requires access to HH's coverage matrix
*/
async function addContextToMutations() {
    const mutationsJsonPath = utils.staticConf.mutationsJsonPath;

    if (fs.existsSync(mutationsJsonPath)) {
        let mutations = JSON.parse(fs.readFileSync(mutationsJsonPath, 'utf8'));
        let contractKeys = Object.keys(mutations);

        for (let key of contractKeys) {
            console.log("Extracting context for mutation of ", key);
            for (let mutation of mutations[key]) {

                console.log(chalk.yellow(`\nExtracting function line info for : ${mutation.id}: ${path.basename(mutation.file)}`));
                mutation = getMutationFunctionStartEnd(mutation)

                fs.writeFileSync(mutationsJsonPath, JSON.stringify(mutations, null, '\t'), function (err) {
                    if (err) return console.log(err);
                });
            }
        }
        console.log("Extended mutations saved to " + mutationsJsonPath);

    } else {
        throw new Error(chalk.red(mutationsJsonPath + " does not exist!"))
    }
}

/**
 * Extends a mutation object with the start and end line of its function. 
 * If the mutant is applied to a state variable, the fields remain null.
 * @param {Object} mutation - the mutation object
 * @returns the mutation with additional funcStartLine and funcEndLine fields
 */
function getMutationFunctionStartEnd(mutation) {

    const contractName = path.basename(mutation.file);

    //Extend mutation with function start and end lines
    mutation.funcStartLine = null;
    mutation.funcEndLine = null;

    // Determine start and end lines of function 
    if (mutation.functionName && mutation.functionName !== "stateVariable") {
        const contractPath = findContractFile("./contracts", contractName);
        if (contractPath) {
            try {
                const contractCode = fs.readFileSync(contractPath, 'utf8');
                const ast = parser.parse(contractCode, { range: true, loc: true });

                parser.visit(ast, {
                    FunctionDefinition(node) {
                        if (node.name === mutation.functionName) {
                            // Set the start and end lines to the function's position in the file
                            mutation.funcStartLine = node.loc.start.line;
                            mutation.funcEndLine = node.loc.end.line;
                        }
                    }
                });
            } catch (error) {
                console.error(`Error parsing contract file: ${error.message}`);
            }
        }
    }
    return mutation
}


/**
* SMART CONTRACT CONTEXT
*/
const cacheCodeContext = new Map();

/**
* Add codeContext to a mutant. It requires access to the Surya CFG.
* If the CFG is not available, codeContext will be the mutant's original contract code.
* @param {Object} mutation - the mutant object
* @returns the mutant's "codeContext" field
*/
async function addContractContextToMutant(mutation) {

    const pathToCfg = utils.staticConf.suryaCFGPath;
    const contractsDir = utils.getContractsDir();
    const mutatedContractName = path.basename(mutation.file).split(".sol")[0];
    const mutatedFunctionName = mutation.functionName;
    let codeContext = "";

    if (!fs.existsSync(pathToCfg)) {
        console.log(chalk.red(`Warning: CFG file not found: ${pathToCfg}`));
        console.log(`Fallback: Adding ${mutatedContractName} to the mutation's codeContext.`);
        const contractFilePath = findContractFile(contractsDir, `${mutatedContractName}.sol`);
        try {
            codeContext = await fs.readFile(contractFilePath, 'utf8');
            return codeContext;
        } catch (error) {
            console.error(`Error reading file: ${error.message}`);
            throw error;
        }

    } else {
        codeContext = await getRelevantContractContext(pathToCfg, mutatedContractName, mutatedFunctionName, contractsDir)
        return codeContext;
    }
}


/**
 * Produces a file that contains the relevant functions and modifiers for a mutant.
 * These are the functions and modifiers that can reach the mutated function.
 * It requires access to the Surya CFG.
 * @param {string} pathToCfg - path to the Surya CFG
 * @param {string} mutatedContractName - the mutated contract name (e.g., Particle)
 * @param {string} mutatedFunctionName - the mutated function name (e.g., mint)
 * @param {string} contractsDir - the contracts directory
 * @returns {Promise<string>} a file with extracted code
 */
async function getRelevantContractContext(pathToCfg, mutatedContractName, mutatedFunctionName, contractsDir) {
    // Generate a unique cache key
    const cacheKey = `${mutatedContractName}-${mutatedFunctionName}`;

    // Check if the result is already in the cache
    if (cacheCodeContext.has(cacheKey)) {
        console.log("Cache hit for:", cacheKey);
        return cacheCodeContext.get(cacheKey);
    }

    try {
        // Find the contract file path based on the mutated contract name
        const contractFilePath = findContractFile(contractsDir, `${mutatedContractName}.sol`);

        // Get the list of relevant functions and/or modifiers
        const relevantFunctions = await cfg.getReachingFunctions(pathToCfg, contractFilePath, mutatedContractName, mutatedFunctionName);
        console.log("Relevant functions/modifiers for the mutant:", relevantFunctions);

        // Extract relevant functions, modifiers, and global definitions from the contracts
        const extractedCode = extractRelevantFunctions(relevantFunctions, contractsDir);

        // Store the extracted code in the cache for future use
        cacheCodeContext.set(cacheKey, extractedCode);

        return extractedCode;
    } catch (error) {
        console.error('Error in cacheCodeContext:', error);
    }
}


/**
* Extracts relevant functions from the contracts.
* @param {Array} relevantFunctions - List of relevant functions in the format ['contractName.functionName']
* @param {string} contractsDir - Path to the directory containing contract source files
* @returns {string} - Extracted contract code containing relevant functions grouped by contract
*/
function extractRelevantFunctions(relevantFunctions, contractsDir) {
    let extractedCode = "";

    // Group the functions by contract name
    let functionsByContract = groupFunctionsByContract(relevantFunctions);

    // Iterate over each contract and its relevant functions
    for (const [contractName, functionNames] of Object.entries(functionsByContract)) {

        // Find the contract file within the base directory or its subdirectories
        let contractFilePath = findContractFile(contractsDir, `${contractName}.sol`);

        if (contractFilePath) {
            const contractCode = fs.readFileSync(contractFilePath, 'utf8');

            // Parse the contract code using the Solidity parser
            const relevantCode = parseContractForFunctionsAndGlobals(contractCode, functionNames);

            // Remove single-line comments from the extracted code
            const cleanedCode = cleanExtractedCode(relevantCode.join('\n'));

            // Add the cleaned extracted functions to the final code within a single contract block
            if (cleanedCode.length > 0) {
                extractedCode += `contract ${contractName} {\n${cleanedCode}\n}\n\n`;
            }
        } else {
            console.error(`Contract ${contractName}.sol not found in ${contractsDir} or its subdirectories.`);
        }
    }


    return extractedCode;
}


/**
* Parses the contract code using the Solidity parser and extracts the relevant functions and global definitions.
* @param {string} contractCode - Solidity code of the contract
* @param {Array} functionNames - List of function names to extract
* @returns {Array} - Extracted function and global code blocks
*/
function parseContractForFunctionsAndGlobals(contractCode, functionNames) {
    const ast = parser.parse(contractCode, { range: true, loc: true });

    const extractedCode = [];
    const globalDeclarations = [];

    // Traverse the AST and find relevant function definitions, variables, events, structs, etc.
    parser.visit(ast, {
        // Capture relevant global state variables, events, structs, enums, and modifiers
        StateVariableDeclaration(node) {
            globalDeclarations.push(contractCode.slice(node.range[0], node.range[1] + 1));
        },
        EventDefinition(node) {
            globalDeclarations.push(contractCode.slice(node.range[0], node.range[1] + 1));
        },
        StructDefinition(node) {
            globalDeclarations.push(contractCode.slice(node.range[0], node.range[1] + 1));
        },
        EnumDefinition(node) {
            globalDeclarations.push(contractCode.slice(node.range[0], node.range[1] + 1));
        },
        ModifierDefinition(node) {
            globalDeclarations.push(contractCode.slice(node.range[0], node.range[1] + 1));
        },
        // Capture relevant function definitions
        FunctionDefinition(node) {
            if (node.name && functionNames.includes(node.name)) {
                const functionCode = contractCode.slice(node.range[0], node.range[1] + 1);
                extractedCode.push(functionCode);
            }
        }
    });

    // Combine global declarations and function code into one block of code
    return [...globalDeclarations, ...extractedCode];
}

/**
* Groups the functions by contract name.
* @param {Array} relevantFunctions - List of relevant functions in the format ['contractName.functionName']
* @returns {Object} - Grouped functions by contract name
*/
function groupFunctionsByContract(relevantFunctions) {
    const functionsByContract = {};

    relevantFunctions.forEach(entry => {
        const [contractName, functionName] = entry.split('.');
        if (!functionsByContract[contractName]) {
            functionsByContract[contractName] = [];
        }
        functionsByContract[contractName].push(functionName);
    });

    return functionsByContract;
}


/**
* Finds the contract file by either matching the contract name to the file or searching for the contract definition in any file.
* @param {string} dir - The directory to search for the source files
* @param {string} contractName - The name of the contract to search for
* @returns {string|null} - The full path to the file containing the contract, or null if not found
*/
function findContractFile(dir, contractName) {
    const files = fs.readdirSync(dir);


    for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
            // Recursively search in subdirectories
            const result = findContractFile(fullPath, contractName);
            if (result) return result;
        } else if (file === contractName) {
            // If the file name matches contractName.sol, return its full path
            return fullPath;
        } else if (file.endsWith('.sol')) {
            // If a .sol file is found, read it to check if it contains the contract definition
            const contractCode = fs.readFileSync(fullPath, 'utf8');
            const ast = parser.parse(contractCode, { range: true, loc: true });

            // Traverse the AST to find the contract definition
            let found = false;
            parser.visit(ast, {
                ContractDefinition(node) {
                    if (node.name === contractName.split(".sol")[0]) {
                        found = true;
                    }
                }
            });


            if (found) {
                return fullPath; // Return the path to the file containing the contract
            }
        }
    }
    return null;
}


/**
* Removes single-line comments from Solidity code.
* @param {string} code - Solidity code
* @returns {string} - Solidity code with single-line comments removed
*/
function cleanExtractedCode(code) {
    // Remove single-line comments
    const withoutComments = code.replace(/\/\/.*$/gm, '');

    // Remove empty lines or lines that contain only whitespace
    const withoutEmptyLines = withoutComments.replace(/^\s*[\r\n]/gm, '');

    return withoutEmptyLines;
}

/**
* TEST FILE CONTEXT
*/

const cacheCoveringTests = new Map();

/**
 * Get the information relative to a specific contract from the hardhat coverage matrix
 * @param {Object} mutation - the mutation for which to extract the test data
 * @returns the test data for the mutated contract fromt the matrix
 */
function getContractCoverageFromMatrix(mutation) {
    let coverageMatrix;

    const contractName = path.basename(mutation.file);
    const filePath = utils.staticConf.hardhatCoverageMatrixPath;

    // Step 1: Read and parse the coverage matrix from the file
    try {
        const fileContent = fs.readFileSync(filePath, 'utf8');
        coverageMatrix = JSON.parse(fileContent);
    } catch (error) {
        console.error(`Error reading or parsing file: ${error.message}`);
        return null;
    }

    // Step 2: Find the correct contract in the coverage matrix by checking if the path ends with the contract name
    const matchingContract = Object.keys(coverageMatrix).find(key => key.endsWith(contractName));

    if (!matchingContract) {
        console.error('Contract not found in the coverage matrix.');
        return null;
    }

    const contractCoverage = coverageMatrix[matchingContract];
    if (!contractCoverage) {
        return null;
    }

    return contractCoverage;
}


/**
* Finds the test file that covers the specified contract and range of lines most frequently.
*
* The function searches the coverage matrix to find the test file that covers the given contract
* within the specified line range. 
* If no test file covers the mutated statement line range, it checks the mutated function line range.
* If no test file covers the function line range, it checks the whole contract
*
* @param {Object} mutation - the mutant object
* @param {Object} contractCoverage - the contract coverage data extracted from HH's matrix (or null)

* @returns {Promise<string|null>} A promise that resolves to the name of the test file that covers the contract and line range the most,
*                                 or `null` if no test file is found.
* @throws Will throw an error if the file cannot be read or parsed.
*
* @example
* getMostCoveringTestFile("Particle.sol", 10, 50, "./testMatrix.json")
*     .then(testFile => console.log(testFile))
*     .catch(error => console.error(error));
*/
async function getMostCoveringTestFile(mutation, contractCoverage) {

    if (contractCoverage === null) { return null; }

    const startLine = mutation.startLine;
    const endLine = mutation.startLine;
    const funcStartLine = mutation.funcStartLine;
    const funcEndLine = mutation.funcEndLine;

    /**
     * Counts occurrences of test files covering the given range of lines.
     * @param {number} start - The start line.
     * @param {number} end - The end line.
     * @returns {Object} An object with test file names as keys and their occurrence counts as values.
     */
    function countFileOccurrencesInRange(start, end) {
        const fileOccurrences = {};

        for (let line = start; line <= end; line++) {
            if (contractCoverage[line]) {
                contractCoverage[line].forEach(test => {
                    const testFile = test.file;
                    fileOccurrences[testFile] = (fileOccurrences[testFile] || 0) + 1;
                });
            }
        }

        return fileOccurrences;
    }

    /**
     * Finds the test file with the most occurrences in the given map.
     * @param {Object} fileOccurrences - An object with test file names as keys and their occurrence counts as values.
     * @returns {string|null} The name of the test file with the most occurrences, or null if none are found.
     */
    function getMostFrequentTestFile(fileOccurrences) {
        let maxCount = 0;
        let mostFrequentFile = null;

        for (const [file, count] of Object.entries(fileOccurrences)) {
            if (count > maxCount) {
                maxCount = count;
                mostFrequentFile = file;
            }
        }

        return mostFrequentFile;
    }

    // Step 3: Check test file coverage within the specified range
    const fileOccurrencesInRange = countFileOccurrencesInRange(startLine, endLine);
    let mostFrequentFileInRange = getMostFrequentTestFile(fileOccurrencesInRange);

    // Step 4: If no file covers the input range, check the function range
    if (!mostFrequentFileInRange && (funcStartLine !== null && funcEndLine !== null)) {
        const fileOccurrencesInFunction = countFileOccurrencesInRange(funcStartLine, funcEndLine);
        mostFrequentFileInRange = getMostFrequentTestFile(fileOccurrencesInFunction);
    }

    // Step 5: If no file covers the function range, check the whole contract
    if (!mostFrequentFileInRange) {
        const minLine = Math.min(...Object.keys(contractCoverage).map(Number));
        const maxLine = Math.max(...Object.keys(contractCoverage).map(Number));
        const fileOccurrencesInContract = countFileOccurrencesInRange(minLine, maxLine);
        mostFrequentFileInRange = getMostFrequentTestFile(fileOccurrencesInContract);
    }

    return mostFrequentFileInRange;
}

/**
 * Finds specific test methods from a given test file that cover a specified contract and range of lines.
 *
 * The function searches HardHat's coverage matrix to find test methods (titles) from the specified test file
 * that cover the given contract within the specified line range. If no test methods are found, it returns an empty array.
 *
 * @param {Object} mutation - the mutant object
 * @param {Object} contractCoverage - the contract coverage data extracted from HH's matrix (or null)
 * 
 * @returns {Promise<string[]>} A promise that resolves to an array of test method names (titles) that cover the specified contract and line range,
 *                              or an empty array if no test methods are found.
 * @throws Will throw an error if the file cannot be read or parsed.
 * 
 *  @example
 * getCoveringTestMethods("Particle.sol", "minterV1.ts", 10, 50, "./testMatrix.json")
 *     .then(testMethods => console.log(testMethods))
 *     .catch(error => console.error(error));
 */
async function getCoveringTestMethods(mutation, contractCoverage) {

    if (contractCoverage === null) {
        return [];
    }

    const contractName = path.basename(mutation.file);
    const testFileName = mutation.mostCoveringTestFile;
    const functionName = mutation.functionName || '';
    //Use function start and end line if they are not null
    let startLine = mutation.funcStartLine != null ? mutation.funcStartLine : mutation.startLine;
    let endLine = mutation.funcEndLine != null ? mutation.funcEndLine : mutation.startLine;

    // Create a unique cache key
    const cacheKey = `${contractName}-${testFileName}-${startLine}-${endLine}-${functionName}`;

    // Check if the result is already in the cache
    if (cacheCoveringTests.has(cacheKey)) {
        console.log("Cache hit for:", cacheKey);
        return cacheCoveringTests.get(cacheKey);
    }


    // Step 4: Check if the given test file covers the contract within the specified range
    const testMethods = new Set();

    for (let line = startLine; line <= endLine; line++) {
        if (contractCoverage[line]) {
            contractCoverage[line].forEach(test => {
                if (test.file.endsWith(testFileName)) {
                    testMethods.add(test.title);  // Add the test method (title) to the Set
                }
            });
        }
    }

    const result = Array.from(testMethods);  // Convert the Set to an Array

    // Store the result in the cache
    cacheCoveringTests.set(cacheKey, result);

    return result;
}

/**
* Produces a file that contains the relevant test setup for a mutant.
* The file contains the test setup, and the specified test methods.
* @param {string} filePath - the path to the test file from which to extract the setup
* @param {string[]} testMethods - the list of test methods to be kept in the setup
* @returns the test setup
*/
function getRelevantTestSetup(testFilePath, testMethods = []) {
    const testFileContent = fs.readFileSync(testFilePath, 'utf-8');
    const ast = recast.parse(testFileContent, {
        parser: {
            parse(source) {
                return babel.parse(source, {
                    sourceType: 'module',
                    plugins: ['jsx', 'typescript'],
                });
            },
        },
    });


    const cleanedAST = removeItBlocks(ast, testMethods);
    const fullyCleanedAST = removeEmptyDescribeBlocks(cleanedAST);
    const cleanedContent = recast.print(fullyCleanedAST).code;


    return cleanedContent;
}


function removeItBlocks(ast, exceptions) {
    recast.types.visit(ast, {
        visitCallExpression(path) {
            const { node } = path;
            if (
                node.callee?.type === 'Identifier' &&
                node.callee?.name === 'it'
            ) {
                // Get the test method's name (the first argument to "it")
                const testMethodNameNode = node.arguments[0];
                if (
                    testMethodNameNode &&
                    testMethodNameNode.type === 'StringLiteral' &&
                    !exceptions.includes(testMethodNameNode.value)
                ) {
                    // Prune the "it" block if it's not in the exceptions list
                    path.prune();
                }
            }
            this.traverse(path);
        },
    });
    return ast;
}

function removeEmptyDescribeBlocks(ast) {
    function isEmptyDescribeBlock(node) {
        // Check if the node is a 'describe' or 'describe.only' call
        const isDescribe =
            node.callee?.type === 'Identifier' && node.callee?.name === 'describe';
        const isDescribeOnly =
            node.callee?.type === 'MemberExpression' &&
            node.callee?.object.type === 'Identifier' &&
            node.callee?.object.name === 'describe' &&
            node.callee?.property.type === 'Identifier' &&
            node.callee?.property.name === 'only';

        if (!isDescribe && !isDescribeOnly) {
            return false;
        }

        const body = node.arguments[1];

        // Ensure the body is a function expression
        if (!body || (body.type !== 'FunctionExpression' && body.type !== 'ArrowFunctionExpression')) {
            return false;
        }

        const block = body.body;

        if (block.type !== 'BlockStatement') {
            return false;
        }

        // If the block is empty, the describe block is empty
        if (block.body.length === 0) {
            return true;
        }

        // Recursively check if all statements are empty describe blocks
        return block.body.every((stmt) => {
            if (stmt.type === 'ExpressionStatement' && stmt.expression.type === 'CallExpression') {
                return isEmptyDescribeBlock(stmt.expression);
            }
            return false;
        });
    }

    recast.types.visit(ast, {
        visitCallExpression(path) {
            const { node } = path;

            if (isEmptyDescribeBlock(node)) {
                path.prune();
                return false; // Stop traversing since we already removed the node
            }

            this.traverse(path);
        },
    });
    return ast;
}

module.exports = {
    addContextToMutations: addContextToMutations
};