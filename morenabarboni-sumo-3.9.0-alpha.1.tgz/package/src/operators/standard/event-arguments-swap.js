const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class EASOperator {
    constructor() {
        this.ID = "EAS";
        this.name = "event-arguments-swap";
    }
    
    getMutations(file, source, visit) {
        const mutations = [];

        visit({
            EventDefinition: (node) => {
                const eventName = node.name;
                const eventDefinitionParameters = node.parameters;
                const eventDefinitionIndexedParameters = node.parameters.filter(p => p.isIndexed);

                //If the event definition includes at least two indexed parameters
                if (eventDefinitionIndexedParameters.length > 1) {
                    visit({
                        EmitStatement: (node) => {
                            if (node.eventCall.expression.name === eventName) {

                                //Find event arguments that can be swapped (they must be indexed function calls)
                                let indexedFunctionArguments = findIndexedFunctionArguments(eventDefinitionParameters, node.eventCall.arguments);
                                if (indexedFunctionArguments.length > 1) {

                                    const arg1 = source.substring(indexedFunctionArguments[0].range[0], indexedFunctionArguments[0].range[1] + 1);
                                    const arg2 = source.substring(indexedFunctionArguments[1].range[0], indexedFunctionArguments[1].range[1] + 1);
                                    const startLine = node.loc.start.line;
                                    const endLine = node.loc.end.line;
                                    const start = node.range[0];
                                    const end = node.range[1] + 1;
                                    const functionName = contextParser.getFunctionName(visit,startLine,endLine);
                                    let original = source.substring(start, end); //return statement substring
                                    let replacement = original.replace(arg1, "*").replace(arg2, arg1).replace("*", arg2);
                                    mutations.push(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
                                }
                            }
                        }
                    });
                }
            }
        });

        /**
         * Searches indexed function calls in the argument list of an event emission.
         * @param {*} eventDefinitionParameters the list of parameters in the event definition (permits to determine if the parameter is indexed)
         * @param {*} eventEmissionArguments the list of arguments in the event emission (permits to determine if the argument is a function call)
         * @returns an array of event emission arguments that are indexed function calls
         */
        function findIndexedFunctionArguments(eventDefinitionParameters, eventEmissionArguments) {
            //Filter FunctionCall arguments
            const functionCallObjects = eventEmissionArguments.filter(obj => obj.type === 'FunctionCall');

            //If the eventEmissionArguments array contains at least two function calls
            if (functionCallObjects.length >= 2) {
                const matchingObjects = eventEmissionArguments.filter((obj, index) => {
                    const parameterObj = eventDefinitionParameters[index];
                    return obj.type === 'FunctionCall' && parameterObj && parameterObj.isIndexed === true;
                });

                return matchingObjects;
            }
            return [];
        }

        return mutations;
    }
}


module.exports = EASOperator;
