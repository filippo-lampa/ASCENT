#!/usr/bin/env node
const chalk = require('chalk')
const yargs = require('yargs')
const mutationRunner = require('./src/mutationRunner.js')
const utils = require('./src/utils')
const contextExtractor = require('./src/contextExtractor.js');

yargs
  .usage('$0 <cmd> [args]')
  .command('lookup', 'Generate mutations without starting the testing process', mutationRunner.lookup)
  .command('mutate', 'Generate mutations and save each mutated contract to a file', mutationRunner.mutate)
  .command('coverage', 'Generate and save coverage file inside sumo folder', mutationRunner.coverage)
  .command('pretest', 'Run pretest', mutationRunner.pretest)
  .command('test [startHash] [endHash]', 'Run mutation testing', (yargs) => {
    yargs
      .positional('startHash', {
        type: 'string',
        describe: 'ID of the first mutant to be tested (optional)',
        example: 'm46f345c9'
      })
      .positional('endHash', {
        type: 'string',
        describe: 'ID of the last mutant to be tested (optional)',
        example: 'ma6c345c9'
      })
  }, (argv) => {
    mutationRunner.test(argv.startHash, argv.endHash)
  })
  .command('diff <hash>', 'Show the diff for a mutant', (yargs) => {
    yargs.positional('hash', {
      type: 'string',
      describe: 'mutant hash',
      example: 'ma6c345c9'
    })
  }, mutationRunner.diff)
  .command('list', 'Print a list of enabled mutation operators', mutationRunner.list)
  .command('enable [ID..]', 'Enable one or more mutation operators', (yargs) => {
    yargs
      .positional('ID', {
        type: 'string',
        describe: 'List of IDs of mutation operators to be enabled. ',
        example: 'BOR EED'
      })
  }, (argv) => {
    mutationRunner.enable(argv.ID)
  })
  .command('disable [ID..]', 'Disable one or more mutation operators', (yargs) => {
    yargs
      .positional('ID', {
        type: 'string',
        describe: 'List of IDs of mutation operators to be disabled.',
        example: 'BOR EED'
      })
  }, (argv) => {
    mutationRunner.disable(argv.ID)
  })
  .command('restore', 'Restore the SUT files', utils.restore)
  .command('addMutationsContext', 'Extend mutations.json with testSetup and codeContext', contextExtractor.addContextToMutations)
  .help()
  .alias('h', 'help')
  .demandCommand(1, 'You must specify a command.')
  .strict()
  .fail((msg, err, yargs) => {
    if (msg) console.error(chalk.red(msg));
    if (err) console.error(err);
    yargs.showHelp();
    process.exit(1);
  })
  .argv;