const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class FCDOperator {
    constructor() {
        this.ID = "FCD";
        this.name = "function-call-deletion";
    }
    getMutations(file, source, visit) {
        const mutations = [];
        const ignoreFunctionCalls = ["address", "require", "assert", "revert", "blockhash", "keccak", "sha", "encode",
            "decode", "send", "transfer", "call", "delegateCall", "staticCall", "safeTransfer", "push", "pop"];

        visit({
            FunctionCall: (node) => {
                if (node.expression?.type !== "ElementaryTypeName" &&
                    ignoreFunctionCalls.every(e => !node.expression?.memberName?.startsWith(e)) &&
                    ignoreFunctionCalls.every(e => !node.expression?.name?.startsWith(e))) {
                    //Check the context of the function call
                    let parentNode = contextParser.getFunctionCallParentStatement(visit, node);
                    if (!parentNode) {
                        const start = node.range[0];
                        const end = node.range[1] + 2;
                        const startLine = node.loc.start.line;
                        const endLine = node.loc.end.line;
                        const original = source.slice(start, end);
                        const functionName = contextParser.getFunctionName(visit,startLine,endLine);
                        mutations.push(new Mutation(file, functionName, start, end, startLine, endLine, original, "/*" + original + "*/", this.ID));
                    }
                }
            }
        });

        return mutations;
    }
}


module.exports = FCDOperator;