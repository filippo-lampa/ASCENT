const contextParser = require("../contextParser");
const Mutation = require("../../mutation");
const parser = require('@solidity-parser/parser');

class NVROperator {
  constructor() {
    this.ID = "NVR";
    this.name = "number-value-replacement";
  }

  getMutations(file, source, visit) {

    const ID = this.ID;
    const mutations = [];
    var ignoreIndexes = [];
    var uintStateVarNames = [];

    /**
     * Add address-type expression to the list of indexes to be ignored (covered by AVR)
     * Add gasleft invocations to the list of indexes to be ignored (covered by GVR)   *
     */
    visit({
      FunctionCall: (node) => {
        if (node.expression.name === "address" || node.expression.name === "gasleft") {
          let ignore = {};
          ignore.start = node.range[0];
          ignore.end = node.range[1] + 1;
          ignoreIndexes.push(ignore);
        }
      }
    });

    /**
     * Add global block variables to the list of indexes to be ignored (covered by GVR)
     */
    visit({
      MemberAccess: (node) => {
        var keywords = ['basefee', 'chainid', 'difficulty', 'gaslimit', 'number', 'prevrandao', 'timestamp', 'gasprice', 'value'];
        if ((node.expression.name === 'msg' || node.expression.name === 'tx'
          || node.expression.name === 'block') && keywords.includes(node.memberName)) {
          let ignore = {};
          ignore.start = node.range[0];
          ignore.end = node.range[1] + 1;
          ignoreIndexes.push(ignore);
        }
      }
    });

    /**
    * Visit and mutate each number literal value
    */
    visit({
      NumberLiteral: (node) => {
        // if the number is a fixed point value
        if (node.number % 1 !== 0 && !node.number.includes("_")) {
          mutateFixedPointValue(visit, node);
        }
        //If the number is an integer
        else {
          mutateIntegerValue(visit, node);
        }
      }
    });


    /**
    * Mutates the right hand side of each uint state variable (e.g., uint a = b).
    * Also stores the variable name into "uintStateVarNames" to later recognize
    * its type when a simple assignment is performed (e.g., a = someVar).
    */
    visit({
      StateVariableDeclaration: (node) => {
        if (node.variables.length === 1 && node.variables[0].typeName.name && node.variables[0].typeName.name.startsWith("uint")) {
          uintStateVarNames.push(node.variables[0].name);
          //do not mutate the right-hand side if it is a number literal, binary operation, or tuple expression
          if (node.initialValue && node.initialValue.type !== 'NumberLiteral' && node.initialValue.type !== 'BinaryOperation'
            && node.initialValue.type !== 'TupleExpression') {
            mutateRightHand(node.initialValue, "stateVariable");
          }
        }
      }
    });

    /**
    * Visits each function definition and mutates the relative integer variable
    * declarations and assignments.
    */
    visit({
      FunctionDefinition: (node) => {
        if (node.body) {
          const functionName = node.name;
          var fUintIdentifiers = []; //Identifier of uint parameters or uint variables declared within the current function

          //var returnsInteger = false;
          if (node.parameters) {
            node.parameters.forEach(p => {
              if (p.typeName && p.typeName.name && p.typeName.name.startsWith("uint")) {
                fUintIdentifiers.push(p.name);
              }
            });
          }
          if (node.returnParameters && (node.returnParameters[0].typeName?.name?.startsWith("uint") ||
            node.returnParameters[0].typeName?.name?.startsWith("int"))) {
            //returnsInteger = true;
          }

          //redefine AST to only visit the sliced function
          const fStart = node.range[0];
          const fEnd = node.range[1] + 1;
          const fStartLine = node.loc.start.line;
          const fSource = source.slice(fStart, fEnd);
          const ast = parser.parse(fSource, { range: true, loc: true });
          const visit = parser.visit.bind(parser, ast);

          visit({
            VariableDeclarationStatement: (s) => {
              if (s.variables.length === 1 && s.variables[0].typeName.name && s.variables[0].typeName.name.startsWith("uint")) {
                //Save new identifier
                fUintIdentifiers.push(s.variables[0].name);
                //do not mutate the right-hand side if it is a number literal, binary operation, or tuple expression
                if (s.initialValue && s.initialValue.type !== 'NumberLiteral' && s.initialValue.type !== 'BinaryOperation'
                  && s.initialValue.type !== 'TupleExpression') {
                  //Adjust range based on node's function
                  let initialValueNode = adjustRangeLoc(s.initialValue, fStart, fStartLine);
                  mutateRightHand(initialValueNode, functionName);
                }
              }
            }
          });
          visit({
            ExpressionStatement: (s) => {
              if (s.expression && s.expression.type === "BinaryOperation" && s.expression.operator === "=") {
                //establish if the variable is a uint by checking previously defined variables in the same function and state variables
                //do not mutate the right-hand side if it is a number literal, binary operation or tuple expression
                if ((fUintIdentifiers.includes(s.expression.left.name) || uintStateVarNames.includes(s.expression.left.name))
                  && s.expression.right && s.expression.right.type !== 'NumberLiteral' && s.expression.right.type !== 'BinaryOperation'
                  && s.expression.right.type !== 'TupleExpression') {
                  let rightHandExprNode = adjustRangeLoc(s.expression.right, fStart, fStartLine);
                  mutateRightHand(rightHandExprNode, functionName);
                }
              }
            }
          });
        }
      }
    });

    /**
    * Mutates the right-hand side of an assignment by adding and removing 1
    * @param {Object} node the right-hand expression node
    * @param {String} functionName the name of the function enclosing the node
    */
    function mutateRightHand(node, functionName) {
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const original = source.slice(start, end);
      const replacement = original + " + 1";
      const replacement2 = original + " - 1";
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "NVR"));
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement2, "NVR"));
    }

    /**
    * Mutates a literal fixed point value by incrementing it and decrementing it based on its decimal positions
    * @param {*} visit the visitor
    * @param {Object} node the fixed point value node
    */
    function mutateFixedPointValue(visit, node) {
      var subdenomination = "";
      if (node.subdenomination) {
        subdenomination = " " + node.subdenomination;
      }
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = contextParser.getFunctionName(visit,startLine,endLine);

      const original = source.slice(start, end);
      let decimals = node.number.toString().split(".")[1].length || 0;
      let inc = parseFloat(node.number) + parseFloat(1 / (10 ** decimals));
      let dec = parseFloat(node.number) - parseFloat(1 / (10 ** decimals));
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, inc + subdenomination, ID));
      if (parseFloat(dec) >= 0) {
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, dec + subdenomination, ID));
      }
    }

    /**
    * Mutates a literal integer value by adding and removing 1
    * @param {*} node the integer value node
    */
    function mutateIntegerValue(visit, node) {
      let subdenomination = "";
      let start = node.range[0];
      let end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = contextParser.getFunctionName(visit,startLine,endLine);
      let original = source.slice(start, end);

      if (node.number.includes("_")) {
        node.number = node.number.replaceAll("_", "");
      }
      if (node.subdenomination) {
        subdenomination = " " + node.subdenomination;
      }
      if (node.number.toString().includes('e') || node.number.toString().includes('E')) {
        //Scientific notation
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, original + " + 1", ID));
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, original + " - 1", ID));
      }
      else if (node.number == 1) {
        var sliced = source.slice(node.range[0] - 1, node.range[0]);
        if (sliced === "-") {
          start = node.range[0] - 1;
          original = source.slice(start, end);
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "0" + subdenomination, ID));
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "-2" + subdenomination, ID));
        }
        else {
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "0" + subdenomination, ID));
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "2" + subdenomination, ID));
        }
      } else if (node.number == 0) {
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "1" + subdenomination, ID));
      } else {
        var num = Number(node.number);
        var inc;
        var dec;

        if (num < Number.MAX_SAFE_INTEGER) {
          inc = num + 1;
          dec = num - 1;
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, dec + subdenomination, ID));
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, inc + subdenomination, ID));
        }
      }
    }

    /**
     * When the source of a node is sliced from the whole contract file, its range and loc are
     * relative to the sliced source. This function re-calculates the range-loc of so that
     * the relative mutations can be correctly applied to the contract. To this end it uses
     * information of an enclosing node (e.g., a function) whose source is the whole contract.
     * @param {*} node the node to be adjusted
     * @param {*} rangeOffset the range offset
     * @param {*} locOffset the line of code offset
     * @returns the adjusted node with correct ranges-locs
     */
    function adjustRangeLoc(node, rangeOffset, locOffset) {
      let adjustedNode = node;
      adjustedNode.range[0] += rangeOffset;
      adjustedNode.range[1] += rangeOffset;
      adjustedNode.loc.start.line += locOffset - 1;
      adjustedNode.loc.end.line += locOffset - 1;
      return adjustedNode;
    }

    /**
    * Add a mutation to the mutations list
    * @param {Object} mutation the mutation object
    */
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        //No more than 10 mutations per line, limit for hardcoded int arrays
        if (mutations.filter(m => (m.startLine === mutation.startLine && m.endLine === m.endLine)).length <= 9) {
          let mutate = true;
          for (let i = 0; i < ignoreIndexes.length; i++) {
            const e = ignoreIndexes[i];
            if (mutation.start >= e.start && mutation.end <= e.end) {
              mutate = false;
              break;
            }
          }
          if (mutate) {
            mutations.push(mutation);
          }
        }
      }
    }

    return mutations;
  }
}

module.exports = NVROperator;