const contextParser = require("../contextParser");
const Mutation = require("../../mutation");
const parser = require('@solidity-parser/parser');

class AVROperator {
  constructor() {
    this.ID = "AVR";
    this.name = "address-value-replacement";
  }

  getMutations(file, source, visit) {
    const ID = this.ID;
    const mutations = [];
    var ignoreIndexes = [];
    var stateAddressLiterals = []; //All unique state literal addresses
    var stateAddressIdentifiers = []; //All unique state address identifiers

    visit({
      EmitStatement: (node) => {
        let ignore = {};
        ignore.start = node.range[0];
        ignore.end = node.range[1];
        ignoreIndexes.push(ignore);
      }
    });

    /**
    * Visists the address state variables, one by one.
    * Mutates the right hand side of each address state variable (e.g., address a = 0x...).
    * Also stores the variable name into "stateAddressIdentifiers" to later recognize
    * its type when a simple assignment is performed (e.g., a = someVar).
    */
    visit({
      StateVariableDeclaration: (node) => {
        if (node.variables?.length === 1 && node.variables[0].typeName?.name === "address") {
          //Store state address variable identifier
          if (!stateAddressIdentifiers.includes(node.variables[0].name)) {
            stateAddressIdentifiers.push(node.variables[0].name);
          }
          //If the state variable was initialized
          if (node.initialValue) {
            //Store the literal value if it is a numeric address       
            if (node.initialValue.type === "NumberLiteral" && !stateAddressLiterals.includes(node.initialValue.number)) {
              stateAddressLiterals.push(node.initialValue.number);
            }
            for (let i = stateAddressIdentifiers.length - 1; i >= 0; i--) {
              let replacement = stateAddressIdentifiers[i];
              if (node.variables[0].name !== replacement && (node.initialValue.type === "NumberLiteral" || (node.initialValue.type === "Identifier" && node.initialValue.name !== replacement))) {
                mutateTo(node.initialValue, replacement);
                return; //limit to one mutation
              }
            }
            //If no other mutation was found, mutate to address(0)
            mutateToZeroAddress(node);
          }
        }
      }
    });

    /**
    * Visits each function definition and mutates the relative address
    * variable declarations and assignments.
    */
    visit({
      FunctionDefinition: (node) => {
        if (node.body) {
          //Identifier of address parameters or address variables declared within the current function
          var fAddressIdentifiers = [];

          //Store all function parameters
          if (node.parameters) {
            node.parameters.forEach(p => {
              if (p.typeName?.name === "address") {
                fAddressIdentifiers.push(p.name);
              }
            });
          }

          //redefine AST to only visit the sliced function
          const fStart = node.range[0];
          const fEnd = node.range[1] + 1;
          const fStartLine = node.loc.start.line;
          const fSource = source.slice(fStart, fEnd);
          const ast = parser.parse(fSource, { range: true, loc: true });
          const visit = parser.visit.bind(parser, ast);

          visit({
            VariableDeclarationStatement: (s) => {
              if (s.variables.length === 1 && s.variables[0].typeName?.name === "address") {
                fAddressIdentifiers.push(s.variables[0].name);
                if (s.initialValue) {

                  let initialValueNode = adjustRangeLoc(s.initialValue, fStart, fStartLine);

                  //Use function identifiers to mutate the function
                  for (let i = fAddressIdentifiers.length - 1; i >= 0; i--) {
                    let identifier = fAddressIdentifiers[i];
                    if (initialValueNode.type && s.variables[0].name !== identifier && ((initialValueNode.type === "Identifier" && initialValueNode.name !== identifier) || initialValueNode.type !== "Identifier")) {
                      mutateTo(initialValueNode, identifier);
                      return; //limit to one mutation
                    }
                  }
                  //If no valid mutation was found, replace the target with a global identifier or a standard address
                  let adjustedRangeNode = adjustRangeLoc(s, fStart, fStartLine);
                  if (!mutateToStateVar(adjustedRangeNode)) {
                    mutateToZeroAddress(adjustedRangeNode);
                  }
                }
              }
            }
          });

          visit({
            ExpressionStatement: (s) => {
              //If the statement is a simple assignment
              if (s.expression?.type === "BinaryOperation" && s.expression.operator === "=") {
                //Establish if the variable is an address by checking previously defined variables in the same function and state variables
                //Checks both the left-hand side identifier, and the right-hand side one (if present)
                if (fAddressIdentifiers.includes(s.expression.left.name) || stateAddressIdentifiers.includes(s.expression.left.name) ||
                  fAddressIdentifiers.includes(s.expression.right?.name) || stateAddressIdentifiers.includes(s.expression.right?.name)) {
                  let rightHandExprNode = adjustRangeLoc(s.expression.right, fStart, fStartLine);
                  //Search for a valid replacement within the same function
                  for (let i = 0; i < fAddressIdentifiers.length; i++) {
                    let identifier = fAddressIdentifiers[i];
                    if (rightHandExprNode.type && s.expression.left.name !== identifier && ((rightHandExprNode.type === "Identifier" && rightHandExprNode.name !== identifier) || rightHandExprNode.type !== "Identifier")) {
                      mutateTo(rightHandExprNode, identifier);
                      return; //limit to one mutation
                    }
                  }
                  //If no valid mutation was found, replace the target with a global identifier or a standard address
                  let adjustedRangeNode = adjustRangeLoc(s, fStart, fStartLine);
                  if (!mutateToStateVar(adjustedRangeNode)) {
                    mutateToZeroAddress(adjustedRangeNode);
                  }
                }
              }
            }
          });

          visit({
            FunctionCall: (node) => {
              for (let i = 0; i < node.arguments.length; i++) {
                const arg = node.arguments[i];
                let argNode = adjustRangeLoc(arg, fStart, fStartLine);

                if (arg.type === "Identifier" && fAddressIdentifiers.includes(arg.name) || stateAddressIdentifiers.includes(arg.name)) {
                  for (let i = 0; i < fAddressIdentifiers.length; i++) {
                    let identifier = fAddressIdentifiers[i];
                    if (argNode.name !== identifier) {
                      mutateTo(argNode, identifier);
                      break; //limit to one mutation per argument
                    }
                  }
                } else if ((arg.type === "FunctionCall" && arg.expression?.name === "address") || (arg.type === "MemberAccess" && arg.memberName === "sender")) {
                  for (let i = 0; i < fAddressIdentifiers.length; i++) {
                    let identifier = fAddressIdentifiers[i];
                    mutateTo(argNode, identifier);
                    break; //limit to one mutation per argument                 
                  }
                }
              }
            }
          });
        }
      }
    });

    /**
  * Mutates a the right-hand side of an Address VariableDeclarationStatement or Assignment to address zero
  * @param {*} node an Address type VariableDeclarationStatement or ExpressionStatement
  * @returns true if the node was mutated, false otherwise
   */
    function mutateToZeroAddress(node) {

      let start, end;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;

      //Mutate declarations
      if (node.type === "VariableDeclarationStatement" || node.type === "StateVariableDeclaration") {
        start = node.initialValue.range[0];
        end = node.initialValue.range[1] + 1;
        const original = source.slice(start, end);

        if (original !== "address(0)") {
          const functionName = contextParser.getFunctionName(visit, startLine, endLine);
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "address(0)", ID));
          return true;
        }
      }

      //Mutate assignments
      else if (node.type === "ExpressionStatement") {
        start = node.expression.right.range[0];
        end = node.expression.right.range[1] + 1;
        const original = source.slice(start, end);

        if (original !== "address(0)") {
          const functionName = contextParser.getFunctionName(visit, startLine, endLine);
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "address(0)", ID));
          return true;
        }
      }
    }


    /**
   * Mutates a the right-hand side of an Address VariableDeclarationStatement or Assignment to a state variable identifier
   * @param {*} node an Address type VariableDeclarationStatement or ExpressionStatement
   * @returns true if the node was mutated, false otherwise
   */
    function mutateToStateVar(node) {
      let stateVarReplacements = stateAddressLiterals.concat(stateAddressIdentifiers);

      if (stateVarReplacements.length > 0) {
        for (let i = stateVarReplacements.length - 1; i >= 0; i--) {
          let replacement = stateVarReplacements[i];
          //Mutate declarations
          if (node.expression?.type === "VariableDeclarationStatement" && (node.initialValue.type !== "Identifier"
            || (node.initialValue.type === "Identifier" && node.initialValue.name !== replacement))) {
            mutateTo(node.initialValue, replacement);
            return true;
          }

          //Mutate assignments
          else if (node.type === "ExpressionStatement" && (node.expression.right.type !== "Identifier"
            || (node.expression.right.type === "Identifier" && node.expression.right.name !== replacement))) {
            mutateTo(node.expression.right, replacement);
            return true;
          }
        }
      }
      return false;
    }

    /**
    * Mutates an address value node to a given replacement
    * @param {Object} node address node
    * @param {String} replacement the replacement to be applied    * 
    */
    function mutateTo(node, replacement) {
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const original = source.slice(start, end);
      const functionName = contextParser.getFunctionName(visit, startLine, endLine);

      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, ID));
    }

    /**
   * When the source of a node is sliced from the whole contract file, its range and loc are
   * relative to the sliced source. This function re-calculates the range-loc of so that
   * the relative mutations can be correctly applied to the contract. To this end it uses
   * information of an enclosing node (e.g., a function) whose source is the whole contract.
   * @param {*} node the node to be adjusted
   * @param {*} rangeOffset the range offset
   * @param {*} locOffset the line of code offset
   * @returns the adjusted node with correct ranges-locs
   */
    function adjustRangeLoc(node, rangeOffset, locOffset) {
      let adjustedNode = node;
      adjustedNode.range[0] += rangeOffset;
      adjustedNode.range[1] += rangeOffset;
      adjustedNode.loc.start.line += locOffset - 1;
      adjustedNode.loc.end.line += locOffset - 1;
      return adjustedNode;
    }


    /**
     * Push a mutation to the generated mutations list
     * @param {Object} mutation the mutation
    */
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        for (let i = 0; i < ignoreIndexes.length; i++) {
          const e = ignoreIndexes[i];
          if (mutation.start >= e.start && mutation.end <= e.end) {
            return;
          }
        }
        mutations.push(mutation);
      }
    }

    return mutations;
  }
}



module.exports = AVROperator;