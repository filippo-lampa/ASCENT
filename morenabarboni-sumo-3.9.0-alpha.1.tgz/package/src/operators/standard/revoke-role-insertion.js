const contextParser = require("../contextParser");
const Mutation = require("../../mutation");
const parser = require('@solidity-parser/parser');

class RRIOperator {
    constructor() {
        this.ID = "RRI";
        this.name = "revoke-role-insertion";
    }

    getMutations(file, source, visit) {
        const mutations = [];
        var importType;

        //The contract must be using OpenZeppelin's AccessControlUpgradeable
        visit({
            ImportDirective: (node) => {
                if (node.path.includes("AccessControl") || node.path.includes("AccessControlUpgradeable")) {
                    importType = "AccessControl";
                } else if (node.path.includes("Ownable") || node.path.includes("OwnableUpgradeable")) {
                    importType = "Ownable";
                }
            }
        });

        if (importType === "AccessControl") {
            //First, check if the function is using an onlyOwner modifier
            visit({
                FunctionDefinition: (node) => {
                    if (node.body && !node.isConstructor && !node.isReceiveEther && !node.isFallback &&
                        (!node.stateMutability || (node.stateMutability !== "pure" && node.stateMutability !== "view"))) {
                        let canMutate = false;
                        let adminRoleName;

                        //Visit function body
                        const functionName = node.name;
                        const fStart = node.range[0];
                        const fEnd = node.range[1] + 1;
                        const fSource = source.slice(fStart, fEnd);
                        const ast = parser.parse(fSource, { range: true, loc: true });
                        const visit = parser.visit.bind(parser, ast);

                        visit({
                            FunctionCall: (node) => {
                                //Look for OpenZeppelin's hasRole usage to check if the function is only callable by an admin 
                                if (node.expression.name === "hasRole") {
                                    if (node.arguments.length === 2 && node.arguments[0].name.toLowerCase().includes("admin") && node.arguments[1].memberName === "sender") {
                                        adminRoleName = node.arguments[0].name;
                                        canMutate = true;
                                    } else if (node.arguments.length === 2 && !node.arguments[0].name.toLowerCase().includes("admin") && node.arguments[1].memberName === "sender") {
                                        canMutate = false;
                                    }
                                }
                            }
                        });

                        //Add a revokerole + _grantRole invocation at the end of the restricted function
                        if (canMutate) {
                            let revokeStatement = "revokeRole(" + adminRoleName + ",msg.sender);\n_grantRole(" + adminRoleName + ",msg.sender);\n";
                            const start = node.body.range[1] - 1;
                            const end = node.body.range[1];
                            const startLine = node.body.loc.end.line;
                            const endLine = node.body.loc.end.line;
                            const original = source.slice(start, end); //End of function body {
                            const replacement = original + " " + revokeStatement;
                            pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
                        }
                    }
                }
            });
        }
        else if (importType === "Ownable") {
            //Check if the function is using an onlyOwner modifier
            visit({
                FunctionDefinition: (node) => {

                    if (node.modifiers.length > 0) {
                        node.modifiers.forEach(m => {
                            if (m.name === "onlyOwner") {
                                const functionName = node.name;
                                const revokeStatement = "renounceOwnership();\n _transferOwnership(msg.sender);";
                                const start = node.body.range[1] - 1;
                                const end = node.body.range[1];
                                const startLine = node.body.loc.end.line;
                                const endLine = node.body.loc.end.line;
                                const original = source.slice(start, end); //End of function body {
                                const replacement = original + " " + revokeStatement;
                                pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
                            }
                        });
                    }
                }
            });
        }

        //Apply mutations
        function pushMutation(mutation) {
            //Limit RRI mutants to 3 per contract
            if (mutations.length < 3 && !mutations.find(m => m.id === mutation.id)) {
                mutations.push(mutation);
            }
        }

        return mutations;
    }
}


module.exports = RRIOperator