const chalk = require('chalk')
const fs = require('fs')
const utils = require("../utils");
const mutOpsConfigPath = utils.staticConf.mutOpsConfigPath
const mutOpsConfig = require(mutOpsConfigPath)

const AOROperator = require('./standard/assignment-replacement')
const AACOperator = require('./standard/address-aliasing-check')
const ACMOperator = require('./standard/argument-change-overloaded-call')
const AMROperator = require('./standard/array-member-replacement')
const AVROperator = require('./standard/address-value-replacement')
const BCRDOperator = require('./standard/break-continue-replacement')
const BOROperator = require('./standard/binary-replacement')
const BVROperator = require('./standard/boolean-value-replacement')
const CAOOperator = require('./optimization/compound-assignment-optimization')
const CBDOperator = require('./standard/catch-block-deletion')
const CEROperator = require('./standard/casting-expression-replacement')
const CSCOperator = require('./standard/conditional-statement-change')
const DLOOperator = require('./optimization/data-location-optimization')
const DODOperator = require('./standard/delete-operator-deletion')
const EROperator = require('./standard/enum-replacement')
const EASOperator = require('./standard/event-arguments-swap')
const EEDOperator = require('./standard/event-emission-deletion')
const EHDOperator = require('./standard/exception-handling-deletion')
const FCDOperator = require('./standard/function-call-deletion')
const FVOOperator = require('./optimization/function-visibility-optimization')
const GVROperator = require('./standard/global-variable-replacement')
const HLROperator = require('./standard/hex-literal-replacement')
const ISDOperator = require('./standard/initialization-statement-deletion')
const LSCOperator = require('./standard/loop-statement-change')
const MCROperator = require('./standard/math-crypto-function-replacement')
const MODOperator = require('./standard/modifier-deletion')
//const MOIOperator = require('./standard/modifier-insertion')
const NVROperator = require('./standard/number-value-replacement')
const OLFDOperator = require('./standard/overloaded-function-deletion')
const OMDOperator = require('./standard/overridden-modifier-deletion')
const ORFDOperator = require('./standard/overridden-function-deletion')
const PKDOperator = require('./standard/payable-deletion')
const PLROperator = require('./standard/precision-loss-replacement')
const RRIOperator = require('./standard/revoke-role-insertion')
const RSDOperator = require('./standard/return-statement-deletion')
//const RSIOperator = require('./standard/require-statement-insertion')
const RVSOperator = require('./standard/return-values-swap')
//const SCECOperator = require('./standard/switch-call-expression-casting')
const SCDOperator = require('./standard/selfdestruct-call-deletion')
const SKIDOperator = require('./standard/super-keyword-insertion-deletion')
const SVROperator = require('./standard/string-value-replacement')
const TOROperator = require('./standard/transaction-origin-replacement')
const TRCOperator = require('./standard/transfer-return-check')
const UBOOperator = require('./optimization/unchecked-block-optimization')
const UORDOperator = require('./standard/unary-replacement')
const VUROperator = require('./standard/variable-unit-replacement')
const VVOOperator = require('./optimization/variable-visibility-optimization');

class MutationGenerator {
  constructor(operators) {
    this.operators = operators;
  }
  /**
   * Generates the mutations.
   * @param {*} file the path of the smart contract to be mutated
   * @param {*} source the content of the smart contract to be mutated
   * @param {*} visit the visitor
   * @returns {Array<object>} - The array of generated mutations.
   */
  getMutations(file, source, visit) {
    let mutations = [];

    for (const operator of this.operators) {

      var enabled = Object.entries(mutOpsConfig)
        .find(pair => pair[0] === operator.ID && pair[1] === true);

      if (enabled) {
        var opMutations = operator.getMutations(file, source, visit);
        mutations = mutations.concat(opMutations);
      }
    }
    return mutations;
  }
  //Show information about enabled mutation operators
  getEnabledOperators() {
    var printString;
    var enabled = Object.entries(mutOpsConfig)
      .filter(pair => pair[1] === true);

    if (enabled.length > 0) {
      //Print enabled operators info
      printString = chalk.bold("\nEnabled Mutation Operators:\n\n");

      for (const entry of enabled) {
        for (let i = 0; i < this.operators.length; i++) {
          const operator = this.operators[i];
          if (operator.ID === entry[0]) {
            printString = printString + "> " + chalk.bold.yellow(operator.ID) + " (" + operator.name + ") \n";
            break;
          }
        }
      }
    } else {
      printString = chalk.red("Warning: No mutation operators enabled.\n");
    }
    return printString;
  }
  /**
   * Enables a mutation operator by ID
   * @param {*} ID the operator ID
   * @returns success status
   */
  enable(ID) {
    var exists = Object.entries(mutOpsConfig)
      .find(pair => pair[0] === ID);

    if (exists) {
      mutOpsConfig[ID] = true;
      fs.writeFileSync(mutOpsConfigPath, JSON.stringify(mutOpsConfig, null, 2), function writeJSON(err) {
        if (err) return console.log(err);
      });
      return true;
    }
    return false;
  }
  //Enables all mutation operators
  enableAll() {
    Object.entries(mutOpsConfig).forEach(pair => {
      mutOpsConfig[pair[0]] = true;
    });
    fs.writeFileSync(mutOpsConfigPath, JSON.stringify(mutOpsConfig, null, 2), function writeJSON(err) {
      if (err) return false;
    });
    return true;
  }
  /**
   * Disables a mutation operator by ID
   * @param {*} ID the operator ID
   * @returns success status
   */
  disable(ID) {
    var exists = Object.entries(mutOpsConfig)
      .find(pair => pair[0] === ID);

    if (exists) {
      mutOpsConfig[ID] = false;
      fs.writeFileSync(mutOpsConfigPath, JSON.stringify(mutOpsConfig, null, 2), function writeJSON(err) {
        if (err) return console.log(err);
      });
      return true;
    }
    return false;
  }
  //Disables all mutation operators
  disableAll() {
    Object.entries(mutOpsConfig).forEach(pair => {
      mutOpsConfig[pair[0]] = false;
    });
    fs.writeFileSync(mutOpsConfigPath, JSON.stringify(mutOpsConfig, null, 2), function writeJSON(err) {
      if (err) return false;
    });
    return true;
  }
}
module.exports = {
  AACOperator: AACOperator,
  ACMOperator: ACMOperator,
  AMROperator: AMROperator,
  AOROperator: AOROperator,
  AVROperator: AVROperator,
  BCRDOperator: BCRDOperator,
  BVROperator: BVROperator,
  BOROperator: BOROperator,
  CAOOperator: CAOOperator,
  CBDOperator: CBDOperator,
  CEROperator: CEROperator,
  ISDOperator: ISDOperator,
  CSCOperator: CSCOperator,
  DLOOperator: DLOOperator,
  DODOperator: DODOperator,
  EASOperator: EASOperator,
  EEDOperator: EEDOperator,
  EHDOperator: EHDOperator,
  EROperator: EROperator,
  FCDOperator: FCDOperator,
  FVOOperator: FVOOperator,
  GVROperator: GVROperator,
  HLROperator: HLROperator,
  NVROperator: NVROperator,
  LSCOperator: LSCOperator,
  MCROperator: MCROperator,
  MODOperator: MODOperator,
  // MOIOperator: MOIOperator,
  OLFDOperator: OLFDOperator,
  OMDOperator: OMDOperator,
  ORFDOperator: ORFDOperator,
  PKDOperator: PKDOperator,
  PLROperator: PLROperator,
  RRIOperator: RRIOperator,
  RSDOperator: RSDOperator,
  //RSIOperator: RSIOperator,
  RVSOperator: RVSOperator,
  // SCECOperator: SCECOperator,
  SCDOperator: SCDOperator,
  SKIDOperator: SKIDOperator,
  SVROperator: SVROperator,
  TOROperator: TOROperator,
  TRCOperator: TRCOperator,
  UBOOperator: UBOOperator,
  UORDOperator: UORDOperator,
  VUROperator: VUROperator,
  VVOOperator: VVOOperator,
  MutationGenerator: MutationGenerator,
}