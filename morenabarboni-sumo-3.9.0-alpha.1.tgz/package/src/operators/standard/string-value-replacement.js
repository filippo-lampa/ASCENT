const contextParser = require("../contextParser");
const Mutation = require("../../mutation");
const parser = require('@solidity-parser/parser');

class SVRoperator {
  constructor() {
    this.ID = "SVR";
    this.name = "string-value-replacement";
  }
  getMutations(file, source, visit) {
    const mutations = [];
    const ignoreFunctions = ["require", "assert", "revert", "keccak256", "sha256", "ripemd160"]; //Do not mutate hashing functions and exception handling messages
    var ignoreNodes = []; //Indexes of nodes to be ignored
    var stringStateVarNames = []; //String state variables

    /**
    * Add functions to the list of indexes to be ignored
    */
    visit({
      FunctionCall: (node) => {
        if (ignoreFunctions.includes(node.expression.name)) {
          let ignore = {};
          ignore.start = node.range[0];
          ignore.end = node.range[1] + 1;
          ignoreNodes.push(ignore);
        }
      }
    });

    /**
     * Add import directives to the list of indexes to be ignored
     */
    visit({
      ImportDirective: (node) => {
        let ignore = {};
        ignore.start = node.range[0];
        ignore.end = node.range[1];
        ignoreNodes.push(ignore);
      }
    });

    /**
    * Visit and mutate each string literal value
    */
    visit({
      StringLiteral: (node) => {
        if (node.value) {
          const functionName = contextParser.getFunctionName(visit, node.loc.start.line, node.loc.end.line);
          mutateEmptyString(visit, node, functionName);
        }
      }
    });

    /**
    * Mutates the right hand side of each string or bytes state variable (e.g., string a = b).
    * Also stores the variable name into "uintStateVarNames" to later recognize
    * its type when a simple assignment is performed (e.g., a = someVar).
    */
    visit({
      StateVariableDeclaration: (node) => {
        //If the variable is assigned a string value (literals excluded) 
        if (node.variables.length === 1 && node.variables[0].typeName.name) {
          //If a bytes variable is assigned a string literal, store it 
          if (node.variables[0].typeName.name.startsWith("bytes") && node.initialValue && node.initialValue.type === "StringLiteral") {
            stringStateVarNames.push(node.variables[0].name);
          } else if (node.variables[0].typeName.name === "string") {
            stringStateVarNames.push(node.variables[0].name);
            if (node.initialValue && node.initialValue.type !== "StringLiteral") {
              mutateEmptyString(visit, node.initialValue, "stateVariable");
            }
          }
        }
      }
    });


    /**
     * Visits each function definition and mutates the relative string/valid bytes variables
     * declarations and assignments.
     */
    visit({
      FunctionDefinition: (node) => {
        if (node.body) {
          const functionName = node.name;
          var fStringIdentifiers = []; //Identifier of string parameters or variables declared within the current function
          if (node.parameters) {
            node.parameters.forEach(p => {
              if (p.typeName && p.typeName.name && p.typeName.name === "string") {
                fStringIdentifiers.push(p.name);
              }
            });
          }

          //redefine AST to only visit the sliced function
          const fStart = node.range[0];
          const fEnd = node.range[1] + 1;
          const fStartLine = node.loc.start.line;
          const fSource = source.slice(fStart, fEnd);
          const ast = parser.parse(fSource, { range: true, loc: true });
          const visit = parser.visit.bind(parser, ast);

          //Check and mutate string variable declarations (string stringVar = ...)
          visit({
            VariableDeclarationStatement: (s) => {
              if (s.variables.length === 1 && s.variables[0].typeName.name) {
                if (s.variables[0].typeName.name.startsWith("bytes") && s.initialValue && s.initialValue.type === "StringLiteral") {
                  //Save new identifier
                  fStringIdentifiers.push(s.variables[0].name);
                } else if (s.variables[0].typeName.name === "string") {
                  //Save new identifier
                  fStringIdentifiers.push(s.variables[0].name);
                  //do not mutate the right-hand side if it is a string literal
                  if (s.initialValue && s.initialValue.type !== 'StringLiteral') {
                    //Adjust range based on node's function
                    let initialValueNode = adjustRangeLoc(s.initialValue, fStart, fStartLine);
                    mutateEmptyString(visit, initialValueNode, functionName);
                  }
                }
              }
            }
          });
          //Check and mutate simple string variable assignments (stringVar = ...)
          visit({
            ExpressionStatement: (s) => {
              if (s.expression && s.expression.type === "BinaryOperation" && s.expression.operator === "=") {
                //establish if the variable is a string by checking previously defined variables in the same function and state variables
                //do not mutate the right-hand side if it is a string literal
                if ((fStringIdentifiers.includes(s.expression.left.name) || stringStateVarNames.includes(s.expression.left.name))
                  && s.expression.right && s.expression.right.type !== 'StringLiteral') {
                  let rightHandExprNode = adjustRangeLoc(s.expression.right, fStart, fStartLine);
                  mutateEmptyString(visit, rightHandExprNode, functionName);
                }
              }
            }
          });
        }
      }
    });


    /**
    * Mutates the right-hand side of an assignment to the empty string
    * @param {*} visit the visitor
    * @param {Object} node the right-hand expression node
    * @param {null} [functionName=null] the name of the function enclosing the node
    */
    function mutateEmptyString(visit, node, fName = null) {
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = (fName === null) ? contextParser.getFunctionName(visit, start, end) : fName;
      const original = source.slice(start, end);
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "\"\"", "SVR"));
    }

    /**
       * When the source of a node is sliced from the whole contract file, its range and loc are
       * relative to the sliced source. This function re-calculates the range-loc of so that
       * the relative mutations can be correctly applied to the contract. To this end it uses
       * information of an enclosing node (e.g., a function) whose source is the whole contract.
       * @param {*} node the node to be adjusted
       * @param {*} rangeOffset the range offset
       * @param {*} locOffset the line of code offset
       * @returns the adjusted node with correct ranges-locs
       */
    function adjustRangeLoc(node, rangeOffset, locOffset) {
      let adjustedNode = node;
      adjustedNode.range[0] += rangeOffset;
      adjustedNode.range[1] += rangeOffset;
      adjustedNode.loc.start.line += locOffset - 1;
      adjustedNode.loc.end.line += locOffset - 1;
      return adjustedNode;
    }

    /**
    * Add a mutation to the mutations list
    * @param {Object} mutation the mutation object
    */
    function pushMutation(mutation) {
      let mutate = true;
      for (let i = 0; i < ignoreNodes.length; i++) {
        const e = ignoreNodes[i];
        if (mutation.start >= e.start && mutation.end <= e.end) {
          mutate = false;
          break;
        }
      }
      if (mutate && !mutations.find(m => m.id === mutation.id)) {
        mutations.push(mutation);
      }
    }

    return mutations;
  }
}


module.exports = SVRoperator;