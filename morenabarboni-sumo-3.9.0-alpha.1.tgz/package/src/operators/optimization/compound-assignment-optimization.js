const contextParser = require("../contextParser");
const Mutation = require('../../mutation')

class CAOOperator {
  constructor() {
    this.ID = "CAO";
    this.name = "compound-assignment-optimization";
  }
  getMutations(file, source, visit) {
    const mutations = [];

    visit({
      BinaryOperation: (node) => {
        const start = node.range[0];
        const end = node.range[1] + 1;
        const startLine = node.loc.start.line;
        const endLine = node.loc.end.line;
        const original = source.slice(start, end);
        const functionName = contextParser.getFunctionName(visit,startLine,endLine);
        const startLeft = node.left.range[0];
        const endLeft = node.left.range[1] + 1;
        const originalLeft = source.slice(startLeft, endLeft);
        const startRight = node.right.range[0];
        const endRight = node.right.range[1] + 1;
        const originalRight = source.slice(startRight, endRight);
        let replacement;

        switch (node.operator) {
          case '+=':
            replacement = originalLeft + " = " + originalLeft + " + (" + originalRight + ")";
            break;
          case '-=':
            replacement = originalLeft + " = " + originalLeft + " - (" + originalRight + ")";
            break;
          case '*=':
            replacement = originalLeft + " = " + originalLeft + " * (" + originalRight + ")";
            break;
          case '/=':
            replacement = originalLeft + " = " + originalLeft + " / (" + originalRight + ")";
            break;
          case '%=':
            replacement = originalLeft + " = " + originalLeft + " % (" + originalRight + ")";
            break;
          case '<<=':
            replacement = originalLeft + " = " + originalLeft + " << (" + originalRight + ")";
            break;
          case '>>=':
            replacement = originalLeft + " = " + originalLeft + " >> (" + originalRight + ")";
            break;
          case '|=':
            replacement = originalLeft + " = " + originalLeft + " | (" + originalRight + ")";
            break;
          case '&=':
            replacement = originalLeft + " = " + originalLeft + " & (" + originalRight + ")";
            break;
          case '^=':
            replacement = originalLeft + " = " + originalLeft + " ^ (" + originalRight + ")";
            break;
        }
        if (replacement) {
          mutations.push(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
        }
      },
    });

    return mutations;
  }
}


module.exports = CAOOperator
