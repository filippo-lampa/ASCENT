const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class AACOperator {
    constructor() {
        this.ID = "AAC";
        this.name = "address-aliasing-check";
    }

    getMutations(file, source, visit) {

        const mutations = [];

        visit({
            FunctionCall: (node) => {

                //If the node is an address casting of the type address(bytes(identifier))
                if (node.arguments && node.expression && node.expression.name && node.expression.name.startsWith("bytes")
                    && node.arguments[0] && node.arguments[0].type === "Identifier") {
                    //bytes identifier being cast to address
                    let identifier = node.arguments[0].name;
                    //ranges of casting node expression
                    let startCast = node.range[0];
                    let endCast = node.range[1] + 1;
                    let originalCast = source.slice(startCast, endCast);

                    //Only mutate bytes() casts
                    if (originalCast.includes("bytes")) {
                        //expressions to be inserted
                        const mutantIdentifier = "mutant" + identifier;
                        const mutantCast = originalCast.replace(identifier, mutantIdentifier);
                        const insertion = "bytes memory " + mutantIdentifier + " = abi.encodePacked(" + identifier + ");" + mutantIdentifier + "[" + mutantIdentifier + ".length-1] = ~" + mutantIdentifier + "[" + mutantIdentifier + ".length-1];";
                        //retrieve parent node
                        //@todo move this into contextParser
                        const parentNode = getParentStatement(node);

                        if (parentNode) {
                            const startLine = parentNode.loc.start.line;
                            const endLine = parentNode.loc.end.line;
                            const start = parentNode.range[0];
                            const end = parentNode.range[1] + 1;
                            let original = source.slice(start, end);
                            const functionName = contextParser.getFunctionName(visit, startLine, endLine);

                            //Only apply the mutation if there is an address cast and if it is not within a conditional/require statement
                            if ((!original.startsWith("require") && !original.startsWith("if") && !original.startsWith("else")) && original.includes("address(")) {
                                const mutatedOriginal = original.replace(originalCast, mutantCast);
                                const replacement = insertion + "\n" + mutatedOriginal;
                                pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
                            }
                        }
                    }
                }
            }
        });

        /**
         * Given a cast node, looks for its enclosing node
         * @param {Object} castNode - the cast node
         * @returns the castNode's enclosing node
         */
        function getParentStatement(castNode) {
            let nodeStart = castNode.range[0];
            let nodeEnd = castNode.range[1] + 1;
            let parentNode = null;
            let nodeTypes = ["VariableDeclarationStatement", "ExpressionStatement", "EmitStatement", "ReturnStatement", "FunctionCall"];
            for (let i = 0; i < nodeTypes.length; i++) {
                const nodeType = nodeTypes[i];
                visit({
                    [nodeType]: (node) => {
                        if (node.range && nodeStart >= node.range[0] && nodeEnd <= node.range[1] + 1) {
                            parentNode = node;
                        }
                    }
                });
                if (parentNode) break;
            }
            return parentNode;
        }

        /**
         * Push a mutation to the generated mutations list
         * @param {Object} mutation the mutation
        */
        function pushMutation(mutation) {
            if (!mutations.find(m => m.id === mutation.id)) {
                mutations.push(mutation);
            }
        }
        return mutations;
    }
}


module.exports = AACOperator;