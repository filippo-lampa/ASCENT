const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class TRCOperator {
  constructor() {
    this.ID = "TRC";
    this.name = "transfer-return-check";
  }
  getMutations(file, source, visit) {
    const mutations = [];
    const functions = ["transfer", "transferFrom", "send", "call"];
    const ignoreFunctions = ["require", "assert", "revert"];
    var ignoreIndexes = [];

    /**
    * Add exception handling statements to the list of indexes to be ignored
    */
    visit({
      FunctionCall: (node) => {
        if (ignoreFunctions.includes(node.expression.name)) {
          let ignore = {};
          ignore.start = node.range[0];
          ignore.end = node.range[1];
          ignoreIndexes.push(ignore);
        }
      }
    });

    /**
    * Add variable declarations with multiple variables to the list of indexes to be ignored
    * e.g., (bool success, bytes memory returndata) = targets[i].call(...);
    */
    visit({
      VariableDeclarationStatement: (node) => {
        if (node.variables.length > 1) {
          let ignoreNode = false;
          node.variables.forEach(v => {
            if (v?.typeName?.name?.startsWith("bool")) {
              ignoreNode = true;
            }
          });
          if (ignoreNode) {
            let ignore = {};
            ignore.start = node.range[0];
            ignore.end = node.range[1];
            ignoreIndexes.push(ignore);
          }
        }
      }
    });

    /**
    * Add assignments to the list of indexes to be ignored
    */
    visit({
      ExpressionStatement: (node) => {
        if (node?.expression?.type === "BinaryOperation" && node.expression.operator === "=") {
          let ignore = {};
          ignore.start = node.range[0];
          ignore.end = node.range[1];
          ignoreIndexes.push(ignore);
        }
      }
    });

    visit({
      FunctionCall: (node) => {
        if ((node.expression?.type === "MemberAccess" || (node.expression?.expression?.type === "MemberAccess"))) {
          const memberName = node.expression?.memberName || node.expression?.expression?.memberName;
          if (functions.includes(memberName)) {
            var start = node.range[0];
            var end = node.range[1] + 1;
            var startLine = node.loc.start.line;
            var endLine = node.loc.end.line;
            const functionName = contextParser.getFunctionName(visit,startLine,endLine);
            let original = source.slice(start, end);
            let replacement;

            //A traditonal transfer call reverts in case of error - it is replaced with send
            if (memberName === "transfer" && node.arguments.length === 1) {
              replacement = original.replace("transfer", "send");
              pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
            }

            //A token transfer/transferFrom call may either return false, return nothing or revert in case of error - surrounded by require                     
            //A traditional send, call, delegatecall and staticcall return false in case of error - surrounded by require                     
            else if ((memberName === "transfer" && node.arguments.length > 1)
              || memberName === "transferFrom" || memberName === "send" || memberName === "call"
              || memberName === "delegatecall" || memberName === "staticcall") {

              //Check the context of the transfer operation
              let parentNode = contextParser.getTransferParentStatement(visit, node);
              if (parentNode) {
                let transferStart = node.range[0];
                let transferEnd = node.range[1] + 1;
                let start = parentNode.range[0];
                let end = parentNode.range[1] + 1;
                let startLine = parentNode.loc.start.line;
                let endLine = parentNode.loc.end.line;
                let original = source.slice(start, end);
                let replacement, replacement2;

                switch (parentNode.type) {
                  //If the transfer operation is enclosed by a require statement, remove it - (EHD would discard the operation effects)
                  case "FunctionCall":
                    //If the transfer operation is enclosed by an if (without a falsebody), remove it                
                    replacement = source.slice(transferStart, transferEnd) + ";";
                    const temp = source.slice(start);
                    const delimiter = temp.indexOf(";");
                    end = start + delimiter + 1;
                    replacement2 = "/*" + source.slice(start, end) + "*/";
                    break;
                  case "IfStatement":
                    start = parentNode.range[0];
                    end = parentNode.trueBody.range[0];
                    startLine = parentNode.loc.start.line;
                    endLine = parentNode.trueBody.loc.start.line;
                    original = source.slice(start, end);
                    replacement = source.slice(transferStart, transferEnd) + ";";
                    break;
                  //If the transfer operation is in a return, decouple it and return false
                  case "ReturnStatement":
                    replacement = "return true;";
                    replacement2 = source.slice(transferStart, transferEnd) + "; return true;";
                    break;
                  //If the transfer operation is in a variable declaration, set it to false
                  case "VariableDeclarationStatement":
                    let boolVarName = parentNode.variables[0].name;
                    replacement = "bool " + boolVarName + " = true;";
                    replacement2 = source.slice(transferStart, transferEnd) + "; bool " + boolVarName + " = true;";
                    break;
                  default:
                    return;
                }
                pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
                if (replacement2) {
                  pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement2, this.ID));
                }
              }

              //If the transfer operation is "stand-alone" enclose it with a require
              else {
                replacement = "require(" + original + ")";
                pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
              }
            }
          }
        }
      }
    });


    /**
    * Add a mutation to the mutations list
    * @param {Object} mutation the mutation object
    */
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        let mutate = true;
        for (let i = 0; i < ignoreIndexes.length; i++) {
          const e = ignoreIndexes[i];
          if (mutation.start >= e.start && mutation.end <= e.end) {
            mutate = false;
            break;
          }
        }
        if (mutate) {
          mutations.push(mutation);
        }
      }
    }
    return mutations;
  }
}


module.exports = TRCOperator;