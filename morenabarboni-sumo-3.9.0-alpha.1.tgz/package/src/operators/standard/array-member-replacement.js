const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class AMROperator {
    constructor() {
        this.ID = "AMR";
        this.name = "array-member-replacement";
    }

    getMutations(file, source, visit) {
        const mutations = [];
        var stateArrayNodes = []; //Array state variable nodes

        //Save all array VariableDeclaration nodes
        visit({
            VariableDeclaration: (node) => {
                if (node.typeName.type === "ArrayTypeName") {
                    stateArrayNodes.push(node.name);
                }
            }
        });

        //Save all array member access (push and pop)
        visit({
            FunctionCall: (node) => {
                if (node.expression.type === "MemberAccess" && stateArrayNodes.includes(node.expression.expression.name)) {
                    if (node.expression.memberName === "push") {
                        //arrayPushNodes.push(node);
                        mutatePush(node);
                    } else if (node.expression.memberName === "pop") {
                        mutatePop(node);
                    }

                }
            }
        });

        /**
         * Mutates a push() function call
         * @param {Object} node the function call node
         */
        function mutatePush(node) {
            const start = node.range[0];
            const temp = source.slice(start);
            const delimiter = temp.indexOf(";");
            const end = start + delimiter + 1;
            const startLine = node.loc.start.line;
            const endLine = node.loc.end.line;
            const functionName = contextParser.getFunctionName(visit,startLine,endLine);
            const original = source.slice(start, end);
            const replacement = "/*" + original + "*/";
            const replacement2 = original.slice(0, original.indexOf(".")) + ".push()";

            pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "AMR"));
            pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement2, "AMR"));
        }


        /**
        * Mutates a pop() function call
        * @param {Object} node the function call node
        */
        function mutatePop(node) {
            const start = node.range[0];
            const temp = source.slice(start);
            const delimiter = temp.indexOf(";");
            const end = start + delimiter + 1;
            const startLine = node.loc.start.line;
            const endLine = node.loc.end.line;
            const functionName = contextParser.getFunctionName(visit,startLine,endLine);
            const original = source.slice(start, end);
            const replacement = "/*" + original + "*/";
            pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "AMR"));
        }

        /**
         * Push a mutation to the generated mutations list
         * @param {Object} mutation the mutation
        */
        function pushMutation(mutation) {
            if (!mutations.find(m => m.id === mutation.id)) {
                mutations.push(mutation);
            }
        }

        return mutations;
    }
}


module.exports = AMROperator