// External modules
const appRoot = require('app-root-path');
const chalk = require('chalk')
const fs = require("fs");
// Internal modules
const utils = require('./utils');
const coverageGenerator = require('./coverageGenerator');

//SuMo static configuration
const rootDir = utils.win32PathConverter(appRoot.toString());
const coverageReportPath = utils.staticConf.sumoCoverageJsonPath;
//Sumo-config
const coverage = utils.getCoverage();

/**
 * Reduce the mutations number based on some strategy - only coverage-based supported for now. 
 * If using a coverage-based strategy, and the sumo-coverage does not already exist, it returns the original list of mutations without running coverage.
 * @param {Array<Object>} mutations - List of mutations to be tested.
 * @param {Array<string>} testingFrameworks The list of testing framework(s) used within the SUT
 * @returns {Array<Object>} Filtered mutations after adjusting density, or all mutations if sumo-coverage is not available.
 *  */
function lookupPrunedMutations(mutations, testingFrameworks) {

    console.log(chalk.yellow("Pruning Mutations ✂️"));
    let reducedMutations;

    if (testingFrameworks.length > 1 && testingFrameworks.includes("brownie")) {
        console.log(chalk.yellow("Warning: " + testingFrameworks.join(", ") + " detected. Mutant reduction is not available for hybrid Brownie projects, skipped."));
        return mutations
    }

    if (!fs.existsSync(coverageReportPath)) {
        console.log(chalk.yellow("Warning: Coverage report " + coverageReportPath + " not found!"));
        console.log("Mutant reduction skipped. You can run:");
        console.log("- " + chalk.underline("sumo coverage") + " to generate sumo-coverage.json without starting the testing process\n- " + chalk.underline("sumo test") + " to generate sumo-coverage.json and start the testing process\n");
        return mutations;
    }

    //Prune mutations based on coverageCount when possible
    if (coverage.reduceMutants && !testingFrameworks.includes("brownie")) {
        console.log("Detected testing framework(s): " + testingFrameworks.join(", ") + ": pruning mutants based on coverage count ...");
        reducedMutations = pruneMutationsByCoverageCount(mutations);
    }
    //Prune mutations by only removing uncovered mutants
    else {
        if (!coverage.reduceMutants) {
            console.log("CoverageCount reduction strategy is disabled,  pruning uncovered mutants ...");
        }
        else if (testingFrameworks.includes("brownie")) {
            console.log("Detected testing framework(s): " + testingFrameworks.join(", ") + ": pruning uncovered mutants ...");
        }
        reducedMutations = pruneUncoveredMutations(mutations);
    }

    console.log("- Total mutants: " + mutations.length);
    console.log("- Pruned mutants: " + reducedMutations.length + "\n");
    return reducedMutations;
}

/**
 * Reduce the mutations number based on some strategy - only coverage-based supported for now. 
 * If using a coverage-based strategy, and the sumo-coverage does not already exist, it generates it.
 * @param {Array<Object>} mutations - List of mutations to be tested.
 * @param {Array<string>} testingFrameworks The list of testing framework(s) used within the SUT
 * @param {Array<string>} contractsUnderMutation - The smart contracts to be mutated.
 * @param {Array<string>} testsToBeRun - The tests to be run - optionally used for computing coverage.
 * @returns {Array<Object>} Filtered mutations after adjusting density.
 */
function pruneMutations(mutations, testingFrameworks, contractsUnderMutation, testsToBeRun) {

    console.log(chalk.yellow("Pruning Mutations ✂️"));
    let reducedMutations;

    if (!fs.existsSync(coverageReportPath)) {
        console.log(chalk.red("Coverage report " + coverageReportPath + " not found!"));
        console.log("Starting generation of the Coverage Report");
        coverageGenerator.runCoverage(testingFrameworks, contractsUnderMutation, testsToBeRun);
    }
    if (testingFrameworks.length === 1 && testingFrameworks.includes("brownie")) {
        console.log("Detected testing framework(s): brownie.\nRemoving uncovered mutants.");
        reducedMutations = pruneUncoveredMutations(mutations);
    } else if (testingFrameworks.length > 1 && testingFrameworks.includes("brownie")) {
        console.log(chalk.red(testingFrameworks.join(", ") + " detected. Mutant reduction is not available for hybrid Brownie projects! - Mutant reduction skipped."));
        return mutations
    } else {
        console.log("Detected testing framework(s): " + testingFrameworks.join(", ") + ".\nReducing mutants based on coverage count.");
        reducedMutations = pruneMutationsByCoverageCount(mutations);
    }
    console.log("- Total mutants: " + mutations.length);
    console.log("- Pruned mutants: " + reducedMutations.length + "\n");
    return reducedMutations;
}

/**
 * Adjusts the density of mutations applied to the same statement based on their coverage count.
 * If a threshold (maxMutants) is specified by the user, it is used to further reduce the mutations.
 * Assumes that the sumo-coverage has already been generated.
 * @param {Array<Object>} mutations - List of mutations to be tested.
 * @param {number} maxMutants The max number of mutants to be generated retrieved from the sumo-config
 * @returns {Array<Object>} Filtered mutations after adjusting density.
 */
function pruneMutationsByCoverageCount(mutations) {
    let reducedMutations = [];

    let maxMutants = coverage.maxMutants ? parseInt(coverage.maxMutants, 10) : mutations.length;

    if (isNaN(maxMutants) || !Number.isInteger(maxMutants) || maxMutants < 0) {
        // Assign the max value
        maxMutants = mutations.length;
    }

    //Extend each mutant object with its coverageCount
    mutations.forEach(m => {
        m.covCount = getMutantCoverageData(m, "coverageCount");;
    });

    // Cluster mutants based on their location and in descending covCount
    let clusteredMutants = clusterMutantsByStatement(mutations);
    // Compute sorted coverage count for all smart contracts
    let sortedCoverageCounts = getSortedCoverageCounts();

    Object.keys(clusteredMutants).forEach(key => {
        let mutantCoverageCount = clusteredMutants[key][0].covCount;
        let mutantCoverageQuality = classifyCoverageCount(sortedCoverageCounts, mutantCoverageCount);
        let mutantsToAdd = [];

        switch (mutantCoverageQuality) {
            case "Unknown":
            case "Uncovered":
                // Do nothing for unknown or uncovered cases
                break;
            case "Bad":
                mutantsToAdd.push(clusteredMutants[key][0]);
                break;
            case "Medium":
                mutantsToAdd.push(...clusteredMutants[key].slice(0, 2));
                break;
            case "Good":
                mutantsToAdd.push(...clusteredMutants[key]);
                break;
            default:
                break;
        }

        if (mutantsToAdd.length > 0) {
            // Calculate the number of mutants to add and ensure it doesn't exceed the threshold
            const mutantsToAddCount = Math.min(maxMutants - reducedMutations.length, mutantsToAdd.length);

            // Add mutants to reducedMutations array respecting the threshold
            reducedMutations.push(...mutantsToAdd.slice(0, mutantsToAddCount));
        }

        // Stop processing if the threshold is reached
        if (reducedMutations.length >= maxMutants) return;
    });
    return reducedMutations;
}

/**
 * Removes all the mutations applied to uncovered statements.
 * Assumes that the sumo-coverage has already been generated.
 * @param {Array<Object>} mutations - List of mutations to be tested.
 * @returns {Array<Object>} Filtered mutations after removing uncovered mutants.
 */
function pruneUncoveredMutations(mutations) {
    let reducedMutations = [];

    //mutations with unknown coverage data are skipped as well
    mutations.forEach(m => {
        m.covered = getMutantCoverageData(m, "covered");
        if (m.covered) reducedMutations.push(m);
    });

    return reducedMutations;
}

/**
 * Clusters mutants by file, start line, and end line while sorting the clusters by covCount.
 * @param {Array<Object>} mutations - List of mutants to be clustered.
 * @returns {Object} - Object containing mutants clustered by file, start line, and end line.
 */
function clusterMutantsByStatement(mutations) {
    const clusteredMutants = {};

    // Cluster mutants by file and statement
    mutations.forEach(currentMutant => {
        const { file, startLine, endLine, covCount } = currentMutant;
        const key = `${file}_${startLine}_${endLine}`;

        if (!clusteredMutants[key]) {
            clusteredMutants[key] = { mutants: [], covCount }; // Store the covCount directly in the cluster
        }

        clusteredMutants[key].mutants.push(currentMutant);
    });

    // Sort clusters based on covCount of mutants (since all mutants in a cluster share the same covCount)
    const sortedClusters = Object.values(clusteredMutants)
        .sort((a, b) => b.covCount - a.covCount);

    // Reconstruct the sorted clusters into the final object
    const orderedClusteredMutants = sortedClusters.reduce((orderedClusters, cluster) => {
        const { file, startLine, endLine } = cluster.mutants[0]; // Assuming mutants in each cluster share the same file, startLine, and endLine
        const key = `${file}_${startLine}_${endLine}`;
        orderedClusters[key] = cluster.mutants;
        return orderedClusters;
    }, {});

    // Reorder mutants within each cluster based on operator priority criteria
    for (const key in orderedClusteredMutants) {
        if (Object.prototype.hasOwnProperty.call(orderedClusteredMutants, key)) {
            orderedClusteredMutants[key].sort(compareMutants);
        }
    }

    return orderedClusteredMutants;
}

/**
 * Function to compare mutants based on static operator priorities.
 * @param {Object} mutantA - The first mutant object to compare.
 * @param {Object} mutantB - The second mutant object to compare.
 * @returns {number} Returns a number indicating the order of mutants.
 */
function compareMutants(mutantA, mutantB) {
    const priorityA = operatorPriorities[mutantA.operator] || 0;
    const priorityB = operatorPriorities[mutantB.operator] || 0;

    if (priorityA !== priorityB) {
        return priorityA - priorityB;
    } else {
        if (mutantA.operator !== mutantB.operator) {
            return (mutantA.operator < mutantB.operator) ? -1 : 1;
        }
        return 0; // Default: maintain their original order
    }
}

/**
 * Gets a mutant's coverage data ("coverageCount" or "covered") from the "sumo-coverage.json" report
 * @param {Object} mutant the mutant to retrieve coverage data for
 * @param {string} propertyName the coverage property to search for ("coverageCount" or "covered")
 * @returns {number | boolean | null} A number indicating the mutant's coverageCount, or a boolean indicating if the mutant is covered 
 */
function getMutantCoverageData(mutant, propertyName) {
    if (propertyName !== "coverageCount" && propertyName !== "covered") {
        throw new Error(`Unsupported property: ${propertyName}`);
    }

    let file = mutant.file;
    let startLine = mutant.startLine;
    let endLine = mutant.endLine;

    if (!fs.existsSync(coverageReportPath)) {
        throw new Error(chalk.yellow("Coverage report: ") + coverageReportPath + chalk.yellow(" not found!"));
    }
    else {
        const coverageData = JSON.parse(fs.readFileSync(coverageReportPath, "utf8"));
        const contractCoverageData = coverageData.find(con => rootDir + "/" + con.contract === file);

        if (!contractCoverageData) return null;

        //Check if the mutation is inside a function
        const matchingFunction = contractCoverageData.functions.find(fun =>
            (startLine >= fun.start && endLine <= fun.end) || fun.start === -1
        );

        //If the mutation does not match any function
        if (!matchingFunction || matchingFunction === undefined) {
            //Check if the mutation involves a state variable
            const matchingStateVar = contractCoverageData.state_variables.find(svar => (startLine >= svar.start && endLine <= svar.end));
            if (!matchingStateVar || matchingStateVar === undefined) {
                return null; //Unknown mutant coverage data
            } else {
                return matchingStateVar[propertyName] !== null && matchingStateVar[propertyName] !== undefined
                    ? matchingStateVar[propertyName] //state variable coverage data
                    : null; //Unknown mutant coverage data
            }
        }
        // If the mutation matches a function, but the function's coverageCount is unknown,
        // it's not supported by the coverage command (e.g., modifier or constructor for Forge). 
        else if (matchingFunction[propertyName] === null || matchingFunction[propertyName] === undefined) {
            return null; //Unknown mutant coverage data
        }
        /**
        * If:
        * - the matching function is uncovered (coverageCount = 0, covered = false)
        * - the mutation is applied on the whole matching function
        * - the matching function contains an empty/undefined statements array
        * - the statements array exists, but the mutation is applied on the function signature
        * Then: Return the function's coverageCount or covered property instead
        */
        else if (matchingFunction[propertyName] === 0 || matchingFunction[propertyName] === false ||
            (matchingFunction.start === startLine && matchingFunction.end === endLine) ||
            matchingFunction.statements === undefined || matchingFunction.statements?.length === 0 ||
            (matchingFunction.statements?.length > 0 &&
                startLine >= matchingFunction.start && endLine < matchingFunction.statements[0].start)
        ) {
            return matchingFunction[propertyName];
        }
        else {
            //If the function has statements, find the matching statement
            let matchingStatement = matchingFunction.statements.find(stat =>
                startLine === stat.start
            );

            if (matchingStatement !== undefined) {
                return matchingStatement[propertyName];
            }
            /**
             * The coverage report might only include the start line of a statement (Forge).
             * If the statement is long and the mutant is applied after a line break, 
             * the match will not be found.
             * So, we check if the mutant falls within a statement's startLine 
             * and the next statement's startLine (or the end of the function).
             */
            else {
                matchingStatement = matchingFunction.statements.find((stat, index) => {
                    const nextStatement = matchingFunction.statements[index + 1];
                    const nextStatementStart = nextStatement ? nextStatement.start : matchingFunction.end;

                    return startLine >= stat.start && endLine <= nextStatementStart;
                });
                if (matchingStatement !== undefined) {
                    return matchingStatement[propertyName];
                }
            }
        }
    }
}

/**
 * Gets an array of coverageCounts for all statements of all smart contracts sorted in ascending order
 * @returns an array of sorted coverageCounts
 */
function getSortedCoverageCounts() {

    if (!fs.existsSync(coverageReportPath)) throw new Error(chalk.yellow("Coverage report: ") + coverageReportPath + chalk.yellow(" not found!"));

    let coverageCounts = [];

    const coverageData = JSON.parse(fs.readFileSync(coverageReportPath, "utf8"));
    coverageData.forEach(contractCoverageData => {
        if (!contractCoverageData) return null;

        contractCoverageData.functions.forEach(f => {
            if (f.coverageCount > 0) {
                f.statements.forEach(s => {
                    if (s.coverageCount > 0) {
                        coverageCounts.push(s.coverageCount);
                    }
                });
            }
        });
    });

    const sortedCounts = coverageCounts.slice().sort((a, b) => a - b);
    return sortedCounts;
}

/**
 * Classifies coverage count based on quartile boundaries.
 * @param {number[]} sortedCoverageCounts - Array of sorted coverage counts.
 * @param {number|null} currentCoverageCount - Current coverage count to be classified.
 * @returns {string} Returns a string indicating the classification of the coverage count.
 */
function classifyCoverageCount(sortedCoverageCounts, currentCoverageCount) {

    if (currentCoverageCount === 0) {
        return 'Uncovered';
    } else if (currentCoverageCount === null) {
        return 'Unknown';
    }

    const countIndex = sortedCoverageCounts.indexOf(currentCoverageCount);
    const totalCounts = sortedCoverageCounts.length;

    // Calculate quartile boundaries
    const firstQuartileIndex = Math.floor(totalCounts * 0.25);
    const thirdQuartileIndex = Math.floor(totalCounts * 0.75);

    if (countIndex < firstQuartileIndex) {
        return 'Bad';
    } else if (countIndex >= firstQuartileIndex && countIndex <= thirdQuartileIndex) {
        return 'Medium';
    } else {
        return 'Good';
    }
}

const operatorPriorities = {
    "AAC": 10,
    "ACM": 1,
    "AMR": 10,
    "AOR": 8,
    "AVR": 9,
    "BCRD": 9,
    "BOR": 9,
    "BVR": 10,
    "CAO": 1,
    "CBD": 1,
    "CER": 8,
    "CSC": 7,
    "DLO": 1,
    "DOD": 7,
    "EAS": 10,
    "EED": 9,
    "EHD": 10,
    "ER": 10,
    "FCD": 9,
    "FVO": 1,
    "GVR": 10,
    "HLR": 10,
    "ISD": 10,
    "LSC": 7,
    "PKD": 6,
    "PLR": 10,
    "MCR": 1,
    "MOD": 10,
    "MOI": 2,
    "NVR": 8,
    "OLFD": 1,
    "OMD": 1,
    "ORFD": 1,
    "RRI": 10,
    "RSD": 10,
    "RSI": 1,
    "RVS": 1,
    "SCEC": 1,
    "SFID": 1,
    "SKID": 10,
    "SVR": 1,
    "TOR": 10,
    "TRC": 10,
    "UBO": 1,
    "UORD": 10,
    "VUR": 7,
    "VVO": 1
};

module.exports = {
    pruneMutations: pruneMutations,
    lookupPrunedMutations: lookupPrunedMutations
};