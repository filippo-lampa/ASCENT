const appRoot = require('app-root-path');
const rootDir = appRoot.toString().replaceAll("\\", "/");
const fs = require('fs')

const sumoconfig =
`module.exports = {
  project: {
    buildDir: "auto",
    contractsDir: "auto",
    testDir: "auto",
    skipContracts: ["interfaces", "mock", "test"],
    skipTests: [],
    testingFramework: "auto",
  },
  mutationTesting: {
    coverage: {
      enabled: false,
      reduceMutants: false,
      maxMutants: 100000
    },
    testingTimeOutInSec: 500,
    resultsHistory: true
  }
}`;

if (!fs.existsSync(rootDir + "/sumo-config.js")) {
    fs.writeFileSync(rootDir + "/sumo-config.js", sumoconfig)
}