const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class EHDOperator {
  constructor() {
    this.ID = "EHD";
    this.name = "exception-handling-statement-deletion";
  }

  getMutations(file, source, visit) {
    const mutations = [];
    const functions = ["require", "assert", "revert"];
    const ignoreArguments = ["transfer", "transferFrom", "send", "call", "staticcall", "delegatecall"];

    visit({
      FunctionCall: (node) => {
        if (functions.includes(node.expression.name)) {
          //Skip the statement if it includes a transfer operation
          if (node.arguments[0]?.type === "FunctionCall") {
            const memberName = node.arguments[0].expression?.memberName || node.arguments[0].expression?.expression?.memberName;
            if (ignoreArguments.includes(memberName)) {
              return;
            }
          }
          //EHD - Exception Handling statement Deletion
          const start = node.range[0];
          const temp = source.slice(start);
          const delimiter = temp.indexOf(";");
          const end = start + delimiter + 1;
          const startLine = node.loc.start.line;
          const endLine = node.loc.end.line;
          const functionName = contextParser.getFunctionName(visit,startLine,endLine);
          const original = source.slice(start, end);
          const replacement = "/* " + original + " */";
          pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
        }
      }
    });

    visit({
      RevertStatement: (node) => {
        const start = node.range[0];
        const temp = source.slice(start);
        const delimiter = temp.indexOf(";");
        const end = start + delimiter + 1;
        const startLine = node.loc.start.line;
        const endLine = node.loc.end.line;
        const functionName = contextParser.getFunctionName(visit,startLine,endLine);
        const original = source.slice(start, end);
        const replacement = "/* " + original + " */";
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
      }
    });

    /**
    * Push a mutation to the generated mutations list
    * @param {Object} mutation the mutation
    */
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        mutations.push(mutation);
      }
    }

    return mutations;
  }
}


module.exports = EHDOperator;