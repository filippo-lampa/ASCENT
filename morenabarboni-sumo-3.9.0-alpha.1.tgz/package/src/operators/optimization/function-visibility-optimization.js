const contextParser = require("../contextParser");
const Mutation = require('../../mutation')

function FVOOperator() {
  this.ID = "FVO";
  this.name = "function-visibility-optimization";
}

FVOOperator.prototype.getMutations = function (file, source, visit) {
  const mutations = [];

  visit({
    FunctionDefinition: (node) => {
      if (!node.isReceiveEther && !node.isConstructor && !node.isFallback && !node.isVirtual && node.override == null) {
        if (node.body) {
          const start = node.range[0];
          const end = node.body.range[0];
          const functionName = node.name;
          const startLine = node.loc.start.line;
          const endLine = node.body.loc.start.line;
          const original = source.substring(start, end); //function signature  

          if (node.visibility === "public") {
            let replacement = original.replace("public", "external");
            mutations.push(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID));
          }
        }
      }
    }
  });
  return mutations;
};

module.exports = FVOOperator;
