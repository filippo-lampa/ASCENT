const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class ACMOperator {
  constructor() {
    this.ID = "ACM";
    this.name = "argument-change-of-overloaded-method-call";
  }

  getMutations(file, source, visit) {
    const mutations = [];
    var functions = [];
    var overloadedFunctions = [];
    var calls = [];
    var ranges = []; //Visited node ranges

    visitFunctionDefinition(mutate);

    /**
     * Build a overloadedFunctions list with all the overloaded functions within the contract
     * @param {Function} callback the callback to be executed
     */
    function visitFunctionDefinition(callback) {
      //Save ranges of function definitions
      visit({
        FunctionDefinition: (node) => {
          if (!ranges.includes(node.range)) {
            ranges.push(node.range);
            if (node.name) {
              functions.push(node.name);
            }
          }
        }
      });

      //Filter overloaded functions
      const lookup = functions.reduce((a, e) => {
        a[e] = ++a[e] || 0;
        return a;
      }, {});
      overloadedFunctions = functions.filter(e => lookup[e]);
      if (overloadedFunctions.length > 0) {
        callback();
      }
    }

    /**
     * Visits each FunctionCall and checks if the called function is overloaded.
     * If there are multiple calls to the same overloaded method, swaps their arguments.
     */
    function mutate() {
      visit({
        FunctionCall: (node) => {
          if (overloadedFunctions.includes(node.expression.name)) {
            calls.push(node);
          }
        }
      });
      if (calls.length > 0) {

        calls.forEach(f => {
          loop1: for (var i = 0; i < calls.length; i++) {

            var r = calls[i];

            if (f !== r && f.expression.name === r.expression.name) {

              //If the calls have a different number of arguments
              if (f.arguments.length !== r.arguments.length) {
                apply(f, r);
                break;
              }

              //If the calls have the same number of arguments but different order
              else {
                for (var i = 0; i < f.arguments.length; i++) {
                  if (f.arguments[i].type !== r.arguments[i].type) {
                    apply(f, r);
                    break;
                  }
                }
                break;
              }
            }
          }
        });
      }
    }

    /**
     * Apply the mutation - swaps the arguments of two FunctionCall nodes
     * @param {*} originalNode the FunctionCall node to be mutated
     * @param {*} replacementNode the FunctionCall node acting as a replacement
     */
    function apply(originalNode, replacementNode) {

      const oStart = originalNode.range[0];
      const oEnd = originalNode.range[1] + 1;
      const oStartLine = originalNode.loc.start.line;
      const oEndLine = originalNode.loc.end.line;
      const rStart = replacementNode.range[0];
      const rEnd = replacementNode.range[1] + 1;

      const original = source.slice(oStart, oEnd);
      const replacement = source.slice(rStart, rEnd);
      const functionName = contextParser.getFunctionName(visit, oStartLine, oEndLine);
      mutations.push(new Mutation(file, functionName, oStart, oEnd, oStartLine, oEndLine, original, replacement, "ACM"));
    }

    return mutations;
  }
}


module.exports = ACMOperator;
