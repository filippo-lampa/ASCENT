const contextParser = require("../contextParser");
const Mutation = require("../../mutation");
const parser = require('@solidity-parser/parser');

class BVROperator {
  constructor() {
    this.ID = "BVR";
    this.name = "boolean-value-replacement";
  }
  getMutations(file, source, visit) {
    const mutations = [];
    const ignore = ["transfer", "transferFrom", "send", "call", "staticcall", "delegatecall"];
    var boolStateVarNames = [];

    /**
     * Visit and mutate each boolean literal value
     */
    visit({
      BooleanLiteral: (node) => {
        mutateBooleanValue(node);
      }
    });

    /**
    * Mutates the right hand side of each bool state variable (e.g., bool a = b)
    * Stores the variable name into "boolStateVarNames" to later recognize
    * its type when a simple assignment is performed (e.g., a = someVar).
    */
    visit({
      StateVariableDeclaration: (node) => {
        if (node.variables.length === 1 && node.variables[0].typeName.name && node.variables[0].typeName.name === "bool") {
          boolStateVarNames.push(node.variables[0].name);
          //do not mutate the right-hand side if it is a boolean literal, binary or tuple expression
          if (node.initialValue && node.initialValue.type !== 'BooleanLiteral' && node.initialValue.type !== 'BinaryOperation'
            && node.initialValue.type !== 'TupleExpression') {
            mutateRightHand(node.initialValue);
          }
        }
      }
    });

    /**
    * Visits each function definition and mutates the relative boolean
    * variable declarations and assignments.
    */
    visit({
      FunctionDefinition: (node) => {
        if (node.body) {
          var fBoolIdentifiers = []; //Identifier of bool parameters or bool variables declared within the current function
          if (node.parameters) {
            node.parameters.forEach(p => {
              if (p.typeName && p.typeName.name && p.typeName.name === "bool") {
                fBoolIdentifiers.push(p.name);
              }
            });
          }

          //redefine AST to only visit the sliced function
          const fStart = node.range[0];
          const fEnd = node.range[1] + 1;
          const fStartLine = node.loc.start.line;
          const fSource = source.slice(fStart, fEnd);
          const ast = parser.parse(fSource, { range: true, loc: true });
          const visit = parser.visit.bind(parser, ast);

          visit({
            VariableDeclarationStatement: (s) => {
              if (s.variables.length === 1 && s.variables[0].typeName.name && s.variables[0].typeName.name === "bool") {
                //Save new identifier
                fBoolIdentifiers.push(s.variables[0].name);
                //do not mutate the right-hand side if it is a number literal, binary operation, or tuple expression
                if (s.initialValue && s.initialValue.type !== 'BooleanLiteral' && s.initialValue.type !== 'BinaryOperation'
                  && s.initialValue.type !== 'TupleExpression') {
                  //Adjust range based on node's function
                  let initialValueNode = adjustRangeLoc(s.initialValue, fStart, fStartLine);
                  mutateRightHand(initialValueNode);
                }
              }
            }
          });
          visit({
            ExpressionStatement: (s) => {
              if (s.expression && s.expression.type === "BinaryOperation" && s.expression.operator === "=") {
                //establish if the variable is a bool by checking previously defined variables in the same function and state variables
                //do not mutate the right-hand side if it is a boolean literal, binary operation or tuple expression
                if ((fBoolIdentifiers.includes(s.expression.left.name) || boolStateVarNames.includes(s.expression.left.name))
                  && s.expression.right && s.expression.right.type !== 'BooleanLiteral' && s.expression.right.type !== 'BinaryOperation'
                  && s.expression.right.type !== 'TupleExpression') {
                  let rightHandExprNode = adjustRangeLoc(s.expression.right, fStart, fStartLine);
                  mutateRightHand(rightHandExprNode);
                }
              }
            }
          });
        }
      }
    });

    /**
    * Mutates the right-hand side of an assignment into true and false
    * @param {*} node the right-hand expression node
    */
    function mutateRightHand(node) {
      //If the right-hand side a transfer FunctionCall skip the mutation
      if (node.type === "FunctionCall" &&
        ignore.includes(
          node.expression?.memberName || node.expression?.expression?.memberName
        )) { return; }
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = contextParser.getFunctionName(visit,startLine,endLine);
      const original = source.slice(start, end);
      const replacement = "true";
      const replacement2 = "false";
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "BVR"));
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement2, "BVR"));
    }

    /**
    * Mutates a literal value into true or false
    * @param {*} node the boolean value node
    */
    function mutateBooleanValue(node) {
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = contextParser.getFunctionName(visit,startLine,endLine);
      const original = source.slice(start, end);
      if (node.value) {
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "false", "BVR"));
      } else {
        pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, "true", "BVR"));
      }
    }

    /**
    * When the source of a node is sliced from the whole contract file, its range and loc are
    * relative to the sliced source. This function re-calculates the range-loc of so that
    * the relative mutations can be correctly applied to the contract. To this end it uses
    * information of an enclosing node (e.g., a function) whose source is the whole contract.
    * @param {*} node the node to be adjusted
    * @param {*} rangeOffset the range offset
    * @param {*} locOffset the line of code offset
    * @returns the adjusted node with correct ranges-locs
    */
    function adjustRangeLoc(node, rangeOffset, locOffset) {
      let adjustedNode = node;
      adjustedNode.range[0] += rangeOffset;
      adjustedNode.range[1] += rangeOffset;
      adjustedNode.loc.start.line += locOffset - 1;
      adjustedNode.loc.end.line += locOffset - 1;
      return adjustedNode;
    }

    /**
       * Push a mutation to the generated mutations list
       * @param {Object} mutation the mutation
    */
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        mutations.push(mutation);
      }
    }

    return mutations;
  }
}


module.exports = BVROperator;