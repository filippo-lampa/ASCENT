// External modules
const appRoot = require('app-root-path');
const chalk = require('chalk')
const fs = require('fs');
const { execSync, spawnSync } = require("child_process");
const path = require('path')
// Internal modules
const utils = require('./utils')
const rootDir = utils.win32PathConverter(appRoot.toString());

/**
 * Spawns a new compile process through the interface provided by the connected testing framework 
 * If multiple testing frameworks are specified, the compilation is defaulted to the first one
 * @param {string[]} testingFrameworks - The list of testing frameworks used within the SUT
 * @returns {boolean} Indicates whether the compilation process succeeded (true) or failed (false)
 * @throws {Error} If an invalid testing framework is selected or if there's an issue during the compilation
 */
function spawnCompile(testingFrameworks) {

  if (!testingFrameworks || testingFrameworks.length === 0) {
    throw new Error("Error: Invalid input parameters for the compilation process.");
  }

  const packageManager = utils.getPackageManager();

  let compileChild;

  //npx or yarn (.cmd if win32)
  const packageRunner = (packageManager === "npm") ? "npx" : "yarn";
  const packageRunnerCmd = (process.platform === "win32") ? packageRunner + ".cmd" : packageRunner;

  //npm run-script or yarn run (.cmd if win32)
  const packageManagerCmd = (process.platform === "win32") ? packageManager + ".cmd" : packageManager;
  const runScriptCmd = (packageManager === "npm") ? "run-script" : "run";

  let compileCommand;

  switch (testingFrameworks[0]) {
    case "hardhat": compileCommand = packageRunnerCmd + " hardhat compile";
      break;
    case "brownie": compileCommand = "brownie compile";
      break;
    case "forge": compileCommand = "forge build";
      break;
    case "custom": compileCommand = packageManagerCmd + " " + runScriptCmd + " compile";
      break;
    default: throw new Error(`Error: Unsupported testing framework "${testingFrameworks[0]}".`);
  }

  //Spawn compile command
  console.log(chalk.dim(compileCommand));
  compileChild = spawnSync(compileCommand, { stdio: "inherit", shell: true, cwd: rootDir });

  return compileChild.status === 0;
}

/**
 * Spawns a new test process through the interface provided by the connected testing framework 
 * If multiple testing frameworks are specified, it builds a hybrid test script
 * @param {string[]} testingFrameworks The list of testing framework(s) used within the SUT
 * @param {string[]} testFiles The list of test files to be run
 * @param {number} [testingTimeOutInSec=500] The timeout duration for the testing process in seconds retrieved from the sumo-config
 * 
 * * @returns {{ status: number, results:[] }} 
 *          An object containing the exit status and a list of structured test results.
 *          Results contains the mochawesome results (only for HardHat), or an an empty list
 * @returns {number} Status code indicating the result of the testing process
 * @throws {Error} If an invalid testing framework is selected or if there's an issue during the testing process
 */
function spawnTest(testingFrameworks, testFiles) {

  if (!testingFrameworks || testingFrameworks.length === 0) {
    throw new Error("Error: Invalid input parameters for the testing process.");
  }

  const packageManager = utils.getPackageManager();

  //npx or yarn (.cmd if win32)
  const packageRunner = (packageManager === "npm") ? "npx" : "yarn";
  const packageRunnerCmd = (process.platform === "win32") ? packageRunner + ".cmd" : packageRunner;

  //Build test script based on used testing frameworks
  let testScript = buildTestScript(testingFrameworks, testFiles);
  let testCommand;

  //Hybrid
  if (testingFrameworks.length > 1) {
    //Append npx/yarn if script starts with hardhat
    testCommand = (testScript.startsWith("hardhat")) ? `${packageRunnerCmd} ` + testScript : testScript;
  }
  //Hardhat-only
  else if (testingFrameworks[0] === "hardhat") {
    testCommand = `${packageRunnerCmd} ` + testScript;
  }
  //Forge-only, Brownie-only
  else if (testingFrameworks[0] === "forge" || testingFrameworks[0] === "brownie") {
    testCommand = testScript;
  }
  //Custom
  else if (testingFrameworks.length === 1 && testingFrameworks[0] === "custom") {
    const run = (packageManager === "npm") ? "run-script" : "run";
    const packageManagerCmd = (process.platform === "win32") ? packageManager + ".cmd" : packageManager;
    testCommand = `${packageManagerCmd} ` + run + " test";
  }
  else {
    throw new Error("Error: The selected testing framework is not valid.");
  }

  //Spawn test command
  console.log(chalk.dim(testCommand))
  const testChild = spawnSync(testCommand, { stdio: "inherit", shell: true, cwd: rootDir, timeout: utils.getTestingTimeout() * 1000 });

  let status;
  if (testChild.error && testChild.error.code === "ETIMEDOUT") {
    status = 999; //Custom status code for timedout process
  } else {
    status = testChild.status;
  }

  let results = [];
  //Hardhat: Attempt to read mochawesome report to get testResults
  if (testingFrameworks.length == 1 && testingFrameworks[0] == "hardhat") {
    results = parseMochawesomeReport();
  }

  return { status: status, results: results };
}

/**
 * Parses the Mochawesome test report JSON file and returns test results.
 *
 * @returns {Object[]} An array of test results (or an empty array if an error occurs).
 */
function parseMochawesomeReport() {
  const resultsFilePath = path.join(rootDir, "mochawesome-report", "mochawesome.json");
  let results = [];

  if (fs.existsSync(resultsFilePath)) {
    try {
      const rawData = fs.readFileSync(resultsFilePath, "utf-8");
      if (!rawData.trim()) {  // Handle empty files
        console.warn(chalk.yellow("Warning: Mochawesome report file is empty."));
      } else {
        results = JSON.parse(rawData).results;
      }

      // Attempt to clean up the file after reading
      try {
        fs.unlinkSync(resultsFilePath);
      } catch (unlinkError) {
        console.warn(chalk.yellow("Warning: Failed to delete mochawesome report file:", unlinkError.message));
      }

    } catch (error) {
      console.error("Error: Failed to parse Mochawesome test results:", error.message);
    }
  } else {
    console.warn(chalk.yellow("Warning:", resultsFilePath, "not found."));
  }
  return results;
}

/**
 * Builds a test script based on the selected testingFramework(s). In case
 * of multiple frameworks, it concatenates multiple test scripts, and distributes
 * the test files to be executed according to their format.
 * @param {string[]} testingFrameworks The list of testing framework(s) used within the SUT
 * @param {string[]} testFiles The list of test files to be run
 * @returns {string} Test script to be executed
 * @throws {Error} If an invalid testing framework is selected or if there's an issue during script generation
 */
function buildTestScript(testingFrameworks, testFiles) {
  if (!testingFrameworks || testingFrameworks.length === 0) {
    throw new Error("Error: The selected testing framework(s) is not valid.");
  }

  let testScript = "";
  const isOnlyFramework = testingFrameworks.length === 1;
  const runAllTests = utils.getSkipTests().length === 0 && !utils.getCoverage().enabled && testFiles.length > 1;

  testingFrameworks.forEach(framework => {
    let testsForFramework = isOnlyFramework ? testFiles : utils.getTestsForFramework(framework, testFiles);
    let concatCommand = testScript.length > 0;
    let testCommand = "";

    switch (framework) {
      case 'brownie':
        if (runAllTests) { testCommand = "brownie test --exitfirst"; }
        else { testCommand = testsForFramework.length > 0 ? `brownie test ${testsForFramework.join(' ')} --exitfirst` : ''; }
        break;
      case 'hardhat':
        if (runAllTests) { testCommand = "hardhat test --bail" }
        else { testCommand = testsForFramework.length > 0 ? `hardhat test --bail {${testsForFramework.join(' ')}` : '';}
        break;
      case 'forge':
        if (runAllTests) { testCommand = "forge t --fail-fast" }
        else { testCommand = testsForFramework.length > 0 ? `forge t --fail-fast --match-path {${testsForFramework.map(tf => tf.split(rootDir + '/')[1]).join()}}` : ''; }
        break;
      case 'custom':
        break;
      default: throw new Error(`Error: Unsupported testing framework "${framework}".`);
    }

    //Concat commands if needed (for hybrid test suites)
    if (concatCommand && testCommand !== "") {
      testScript += " && " + testCommand
    }
    else if (!concatCommand && testCommand !== "") {
      testScript += testCommand
    }
  });

  return testScript;
}

/**
 * Runs test coverage command based on the used framework
 * @param {string} testingFramework The testing framework
 * @param {string[]} testFiles The list of test files to process coverage for
 * @throws {Error} If an unsupported testing framework is specified or if an error occurs during the coverage process
 */
function spawnCoverage(testingFramework, testFiles) {

  const packageManager = utils.getPackageManager();
  const packageRunner = (packageManager === "npm") ? "npx" : "yarn";

  let command = "";
  switch (testingFramework) {
    case "hardhat":
      command = packageRunner + ` hardhat coverage --testfiles ${testFiles.join(',')}`;
      break;
    case "forge":
      command = `forge coverage --match-path {${testFiles.map(tf => tf.split(rootDir + '/')[1]).join()}} --report lcov`;
      break;
    case "brownie":
      command = `brownie test ${testFiles.join(' ')} --coverage`;
      break;
    default:
      throw new Error(`Error: Unsupported testing framework "${testingFramework}".`);
  }
  console.log(chalk.dim(command));

  try {
    execSync(command, { cwd: rootDir });
  } catch (error) {
    throw new Error(`Error during the ${testingFramework} coverage process: ${error.message}`);
  }
}

module.exports = {
  spawnCompile: spawnCompile,
  spawnTest: spawnTest,
  spawnCoverage: spawnCoverage
};