const contextParser = require("../contextParser");
const Mutation = require('../../mutation')

class VVOoperator {
  constructor() {
    this.ID = "VVO";
    this.name = "variable-visibility-optimization";
  }
  getMutations(file, source, visit) {
    const mutations = [];

    visit({
      StateVariableDeclaration: (node) => {
        if (node.variables[0].typeName.type != "Mapping") {

          const start = node.range[0];
          const end = node.range[1];
          const startLine = node.loc.start.line;
          const endLine = node.loc.end.line;
          const original = source.slice(start, end);
          var varDeclaration = source.substring(node.range[0], node.range[1]);

          if (node.variables[0].visibility && node.variables[0].visibility === "public") {
            let replacement = varDeclaration.replace("public", "internal");
            let replacement2 = varDeclaration.replace("public", "private");
            mutations.push(new Mutation(file, "stateVariable", start, end, startLine, endLine, original, replacement, this.ID));
            mutations.push(new Mutation(file, "stateVariable", start, end, startLine, endLine, original, replacement2, this.ID));
          }
        }
      }
    });
    return mutations;
  }
}


module.exports = VVOoperator;
