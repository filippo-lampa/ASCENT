const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

function DLOOperator() {
  this.ID = "DLO";
  this.name = "data-location-optimization";
}

DLOOperator.prototype.getMutations = function (file, source, visit) {
  const mutations = [];

  visit({
    VariableDeclaration: (node) => {
      if (node.storageLocation) {
        const start = node.range[0];
        const end = node.range[1] + 1;
        const functionName = contextParser.getFunctionName(visit,startLine,endLine);
        const lineStart = node.loc.start.line;
        const lineEnd = node.loc.end.line;
        const original = source.slice(start, end);
        if (node.storageLocation === "storage") {
          replacement = original.replace("storage", "memory");
          mutations.push(new Mutation(file, functionName, start, end, lineStart, lineEnd, original, replacement, this.ID));
        }
      }
    }
  });

  visit({
    FunctionDefinition: (node) => {
      if (!node.isReceiveEther && !node.isFallback && !node.isVirtual && node.override == null && node.body) {
        //Standard function
        if ((node.visibility === "public" || node.visibility === "external") && node.parameters.length > 0) {
          for (let i = 0; i < node.parameters.length; i++) {
            if (node.parameters[i].storageLocation === "memory") {
              const start = node.parameters[i].range[0];
              const end = node.parameters[i].range[1] + 1;
              const lineStart = node.parameters[i].loc.start.line;
              const lineEnd = node.parameters[i].loc.end.line;
              const original = source.substring(start, end); //function signature  
              let replacement = original.replace("memory", "calldata");
              mutations.push(new Mutation(file, start, end, lineStart, lineEnd, original, replacement, this.ID));
            }
          }
        }
      }
    }
  });
  return mutations;
};

module.exports = DLOOperator;
