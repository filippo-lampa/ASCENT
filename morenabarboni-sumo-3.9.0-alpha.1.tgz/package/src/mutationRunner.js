// External modules
const chalk = require('chalk');
const fs = require('fs');
const fse = require('fs-extra');
const glob = require('glob');
const parser = require('@solidity-parser/parser');

// Internal modules
const mutationGenerator = require("./operators/mutationGenerator");
const Reporter = require('./reporter');
const reporter = new Reporter()
const utils = require('./utils');
const testingInterface = require("./testingInterface");
const coverageGenerator = require("./coverageGenerator");
const mutationPruner = require("./mutationPruner");
//SuMo static configuration
const { sumoDir, baselineDir, mutantsDir, contractsGlob, testsGlob } = utils.staticConf;
//SuMo-config
const coverage = utils.getCoverage();
var testingFrameworks = [];
var contractsDir, testDir, buildDir;


/**
 * Creates a MutationGenerator instance with an array of mutation operators.
 * @type {MutationGenerator}
 */
const mutGen = new mutationGenerator.MutationGenerator([
  "AAC", "ACM", "AMR", "AOR", "AVR", "BCRD", "BOR", "BVR", "CAO", "CBD", "CER", "CSC", "DLO",
  "DOD", "EAS", "EED", "EHD", "ER", "FCD", "FVO", "GVR", "HLR", "ISD", "LSC", "PKD", "PLR",
  "MCR", "MOD", "NVR", "OLFD", "OMD", "ORFD", "RRI", "RSD", "RVS", "SCD",
  "SKID", "SVR", "TOR", "TRC", "UBO", "UORD", "VUR", "VVO"
].map(operator => new mutationGenerator[`${operator}Operator`]()));


/**
 * Performs setup actions required before starting mutation testing.
 * @param {Function} callback - Callback function to execute after setup completion.
 * @returns {void}
 */
function setup(callback) {
  reporter.logSetupCheck();

  //Setup sumo dir
  if (!fs.existsSync(sumoDir)) { fs.mkdirSync(sumoDir); }
  utils.setupResultsDir();

  //Get configurable directories and testing frameworks
  //If multiple testing frameworks, only the first one is used for compilation
  testingFrameworks = utils.getTestingFrameworks();
  contractsDir = utils.getContractsDir();
  testDir = utils.getTestDir();
  buildDir = utils.getBuildDir(testingFrameworks[0]);
  utils.getPackageManager()

  reporter.logAndSaveSetup(contractsDir, testDir, buildDir, testingFrameworks);

  //Restore baseline
  if (fs.existsSync(baselineDir)) { fse.emptyDirSync(baselineDir); }
  fse.copySync(testDir, baselineDir + "/test", { overwrite: true });
  fse.copySync(contractsDir, baselineDir + "/contracts", { overwrite: true });

  callback();
}

/**
 * Provides a summary of available mutants without initiating the testing process.
 * @returns {void}
 * @throws {Error} Throws an error if there are issues with file retrieval.
 */
function lookup() {
  setup(() =>
    glob(contractsDir + contractsGlob, (err, contracts) => {
      if (err) throw err;
      glob(testDir + testsGlob, (err, tests) => {
        if (err) throw err;
        let contractsUnderMutation = contractSelection(contracts);
        let testsToBeRun = testSelection(tests);
        reporter.logSelectedFiles(contractsUnderMutation, testsToBeRun, testingFrameworks);
        generateMutations(contractsUnderMutation, testsToBeRun, true, false);
      })
    })
  );
}

/**
 * Provides a summary of available mutants without initiating the testing process and
 * saves the generated .sol mutants to file.
 * @returns {void}
 * @throws {Error} Throws an error if there are issues with file retrieval.
 */
function mutate() {
  setup(() =>
    glob(contractsDir + contractsGlob, (err, contracts) => {
      if (err) throw err;
      glob(testDir + testsGlob, (err, tests) => {
        if (err) throw err;
        let contractsUnderMutation = contractSelection(contracts);
        let testsToBeRun = testSelection(tests);
        reporter.logSelectedFiles(contractsUnderMutation, testsToBeRun, testingFrameworks);
        const mutations = generateMutations(contractsUnderMutation, testsToBeRun, true, false);

        for (const mutation of mutations) {
          mutation.save();
        }
        console.log("Mutants saved to " + mutantsDir);
      })
    })
  );
}

/**
 * Generates mutations for each target contract.
 * @param {Array<string>} contractsUnderMutation - The smart contracts to be mutated.
 * @param {Array<string>} testsToBeRun - The tests to be run - optionally used for computing coverage.
 * @param {boolean} overwriteReports - Overwrite all the generated reports if true.
 * @param {boolean} testingStarted - Generates the necessary artefacts for pruning mutations if true.
 * @returns {Array<object>} - The array of generated mutations.
 */
function generateMutations(contractsUnderMutation, testsToBeRun, overwriteReports, testingStarted) {
  const enabledOperators = mutGen.getEnabledOperators();
  reporter.logLookup(enabledOperators);

  let mutations = []
  let generationTime;
  const startTime = Date.now()

  for (const file of contractsUnderMutation) {
    const source = fs.readFileSync(file, 'utf8');
    const ast = parser.parse(source, { range: true, loc: true });
    const visit = parser.visit.bind(parser, ast);
    mutations.push(...mutGen.getMutations(file, source, visit));
    generationTime = (Date.now() - startTime) / 1000;
  }

  //Prune mutations if a reduction strategy is enabled
  if (coverage.enabled) {
    mutations = testingStarted ?
      mutationPruner.pruneMutations(mutations, testingFrameworks, contractsUnderMutation, testsToBeRun) :
      mutationPruner.lookupPrunedMutations(mutations, testingFrameworks);
  }

  if (overwriteReports) {
    reporter.logLookupSummary(mutations, generationTime);
    reporter.saveMutantGenerationReports(mutations)
  }

  return mutations;
}

/**
 * Entry point for pretest command. Runs the original test suite to ensure that all tests pass.
 * @returns {void}
 * @throws {Error} Throws an error if there are issues with file retrieval.
 */
function runPreTest() {
  setup(() =>
    glob(contractsDir + contractsGlob, (err, contracts) => {
      if (err) throw err;
      glob(testDir + testsGlob, (err, tests) => {
        if (err) throw err;
        //Select contracts to mutate and test files to evaluate
        let contractsUnderMutation = contractSelection(contracts);
        let testsToBeRun = testSelection(tests);
        preTest(contractsUnderMutation, testsToBeRun)
      })
    })
  );
}

/**
 * Runs the original test suite to ensure that all tests pass.
 * @param {string[]} contractsUnderMutation - Array of contracts selected for mutation.
 * @param {string[]} testsToBeRun - Array of tests selected for evaluation.
 * @returns {void}
 */
function preTest(contractsUnderMutation, testsToBeRun) {

  reporter.logPretest();

  utils.cleanBuildDir(buildDir);
  utils.cleanResultsDir(); //Remove old results directory

  reporter.logSelectedFiles(contractsUnderMutation, testsToBeRun, testingFrameworks);

  if (contractsUnderMutation.length === 0) {
    console.log(chalk.red("Error: No contracts to be mutated")); process.exit(1);
  }
  if (testsToBeRun.length === 0) {
    console.log(chalk.red("Error: No tests to be evaluated")); process.exit(1);
  }

  const isCompiled = testingInterface.spawnCompile(testingFrameworks);

  if (isCompiled) {
    const testProcess = testingInterface.spawnTest(testingFrameworks, testsToBeRun)
    if (testProcess.status === 0) {
      console.log(chalk.green("\nPre-test OK.\n"));
    } else {
      throw new Error(chalk.red("\nError: Pre-test failed - original tests should pass."));
    }
  } else {
    throw new Error(chalk.red("\nError: Pre-test failed - original contracts should compile."));
  }
}

/**
 * Starts the mutation testing process.
 * @param {string} [startHash] - Hash of the first mutant to be tested (optional).
 * @param {string} [endHash] - Hash of the last mutant to be tested (optional).
 * @returns {void}
 */
function test(startHash, endHash) {
  setup(() =>
    glob(contractsDir + contractsGlob, (err, contracts) => {
      if (err) throw err;
      glob(testDir + testsGlob, (err, tests) => {
        if (err) throw err;

        //Select contracts to mutate and test files to evaluate
        let contractsUnderMutation = contractSelection(contracts);
        let testsToBeRun = testSelection(tests);

        //Run the pre-test and compile the original contracts
        preTest(contractsUnderMutation, testsToBeRun);

        //Generate mutations
        var mutations = generateMutations(contractsUnderMutation, testsToBeRun, true, true)
        if (startHash) {
          let startIndex = mutations.indexOf(mutations.find(m => m.id === startHash));
          if (startIndex === -1) {
            throw new Error(chalk.red("Error: The specified start hash does not corrispond to any generated mutant."));
          }
          let endIndex = startIndex;
          if (endHash) {
            endIndex = mutations.indexOf(mutations.find(m => m.id === endHash));
            if (endIndex === -1) {
              throw new Error(chalk.red("Error: The specified end hash does not corrispond to any generated mutant."));
            }
          }
          mutations = mutations.slice(startIndex, endIndex + 1);
        }
        //Compile and test each mutant
        reporter.logStartMutationTesting();
        var startTime = Date.now();

        runTest(mutations, testsToBeRun);

        // testing time in seconds
        const testTime = ((Date.now() - startTime) / 1000);

        reporter.logTestSummary(testTime);
        reporter.saveResultsHistory();
      })
    })
  )
}

/**
 * Compiles and tests each mutant, assigning them a status
 * @param {Object[]} mutations - An array of all mutants
 * @param {string[]} testsToBeRun - Array of test files to be run
 */
function runTest(mutations, testsToBeRun) {

  for (let i = 0; i < mutations.length; i++) {

    let mutation = mutations[i];  //Mutant Under Test

    const startTestTime = Date.now();
    reporter.logMutationProgress(i + 1, mutations.length, mutation);

    mutation.apply();
    reporter.logCompile(mutation);
    const isCompiled = testingInterface.spawnCompile(testingFrameworks);

    if (isCompiled) {
      let testProcess = {};
      reporter.logTest(mutation);

      // Only test mutant with its covering tests
      if (coverage.enabled) {
        //Obtain test files covering mutation before it is applied
        const testsCoveringMutant = coverageGenerator.getTestFilesCoveringMutation(mutation.file, mutation.startLine, mutation.endLine, testingFrameworks, testsToBeRun);

        //If no test covers the mutation
        if (testsCoveringMutant.length === 0) {
          testProcess.status = 998; //custom status code for uncovered mutant
        } else {
          testProcess = testingInterface.spawnTest(testingFrameworks, testsCoveringMutant);
        }
      } else {
        testProcess = testingInterface.spawnTest(testingFrameworks, testsToBeRun)
      }
      switch (testProcess.status) {
        case 0: mutation.status = "live"; break;
        case 998: mutation.status = "uncovered"; break;
        case 999: mutation.status = "timedout"; break;
        default: mutation.status = "killed";
      }
      //Update mutant testResults
      if (testingFrameworks.includes("hardhat")) {
        const mochawesomeTestData = reporter.processMochawesomeReport(testProcess.results);
        mutation.testResults = mochawesomeTestData.files;
      }
    } else {
      mutation.status = "stillborn";
    }

    mutation.testingTime = ((Date.now() - startTestTime));
    reporter.updateMutantStatus(mutation);
    mutation.restore();
  }
}

/**
 * Entry point for the sumo coverage command. Initiates the sumo coverage command to generate code coverage.
 * @returns {void}
 * @throws {Error} Throws an error if there are issues with file retrieval.
 */
function runCoverage() {
  setup(() =>
    glob(contractsDir + contractsGlob, (err, contracts) => {
      if (err) throw err;
      glob(testDir + testsGlob, (err, tests) => {
        if (err) throw err;
        if (coverage.enabled) {
          //Select contracts to mutate and test files to evaluate
          let contractsUnderMutation = contractSelection(contracts);
          let testsToBeRun = testSelection(tests);

          preTest(contractsUnderMutation, testsToBeRun);

          //Generate the sumo-coverage.json
          coverageGenerator.runCoverage(testingFrameworks, contractsUnderMutation, testsToBeRun);
        } else {
          console.log("Error: Coverage is disabled. Please enable 'coverage' in your sumo-config.js");
          process.exit(1);
        }
      })
    })
  );
}


/**
 * Selects the contracts to be mutated. It excludes smart contracts skipped by the user in the sumo-config.js.
 * @param  {Array<string>} files - array of paths of all Smart Contracts in the contractsDir 
 * @returns {Array<string>} a list of contracts to be mutated
 */
function contractSelection(files) {
  const skipContracts = utils.getSkipContracts();
  var contractUnderMutation = [];

  for (const file of files) {
    let skipContract = false;
    for (const relCPath of skipContracts) {
      let absolCPath = utils.getContractsDir() + "/" + relCPath;
      if (file.startsWith(absolCPath) && relCPath !== "") {
        skipContract = true;
        break;
      }
    }
    if (!skipContract) {
      contractUnderMutation.push(file)
    }
  }
  return contractUnderMutation;
}

/**
 * Selects the test files to be evaluated. It excludes test files that are not
 * compatible with the selected testing frameworks, and the test files skipped
 * by the user in the sumo-config.js
 * @param  {Array<string>} files - array of paths of all test files in the testDir 
 * @returns {Array<string>} a list of tests to be run
 */
function testSelection(files) {
  const skipTests = utils.getSkipTests();
  let testsToBeRun = [];

  for (const file of files) {
    let skipTest = false;
    for (const relTPath of skipTests) {
      let absolTPath = utils.getTestDir() + "/" + relTPath;
      if (file.startsWith(absolTPath) && relTPath !== "" && !testingFrameworks.includes("custom")) {
        skipTest = true;
        break;
      }
    }
    if (!testingFrameworks.includes("custom")) {
      const isForgeTest = file.endsWith(".t.sol");
      const isBrownieTest = file.endsWith(".py") && (file.includes('test_') || file.includes('_test'));
      const isHardhatTest = file.endsWith(".ts") || file.endsWith(".js") || (file.endsWith(".sol") && !file.endsWith(".t.sol"));

      //Skip forge tests if not required
      if (!testingFrameworks.includes("forge") && isForgeTest) { skipTest = true; }
      //Skip brownie tests if not required
      if (!testingFrameworks.includes("brownie") && isBrownieTest) { skipTest = true; }
      //Skip hardhat tests if not required
      if (!testingFrameworks.includes("hardhat") && isHardhatTest) { skipTest = true; }
    }
    if (!skipTest) {
      testsToBeRun.push(file)
    }
  }
  return testsToBeRun;
}

/**
 * Enable one or more mutation operators.
 * @param {Array<string>} args a list of operators to be enabled. 
 * The list can include simple operator IDs, or cluster names (i.e., default or optimization).
 * If the list is empty, all the mutation operators are enabled.
 */
function enableOperator(args) {
  const optCluster = new Set(["CAO", "DLO", "FVO", "VVO", "UBO"]);

  if (args.length === 0) {
    const success = mutGen.enableAll();
    console.log(success ? "\nAll mutation operators enabled.\n" : "\nError.\n");
  } else if (args[0] === "optimization") {
    mutGen.disableAll();
    optCluster.forEach(ID => mutGen.enable(ID));
    console.log("\nOptimization cluster enabled.\n");
  } else if (args[0] === "standard") {
    mutGen.enableAll();
    optCluster.forEach(ID => mutGen.disable(ID));
    console.log("\nStandard cluster enabled.\n");
  } else {
    console.log();
    args.forEach(ID => {
      const success = mutGen.enable(ID);
      console.log(success ? chalk.bold.yellow(ID) + " enabled." : chalk.red("Error: " + ID + " does not exist."));
    });
    console.log();
  }
}

/**
 * Disable one or more mutation operators
 * @param {Array<string>} args a list of operators to be enabled. 
 * The list can include simple operator IDs, or cluster names (i.e., default or optimization).
 * If the list is empty, all the mutation operators are disabled.
 */
function disableOperator(args) {
  if (args.length === 0) {
    const success = mutGen.disableAll();
    console.log(success ? "\nAll mutation operators disabled.\n" : "\nError.\n");
  } else {
    console.log();
    args.forEach(ID => {
      const success = mutGen.disable(ID);
      console.log(success ? chalk.bold.yellow(ID) + " disabled." : chalk.red("Error: " + ID + " does not exist."));
    });
    console.log();
  }
}

/**
 * Logs the currently enabled mutation operators.
 * @returns {void}
 */
function enabledOperators() {
  console.log(mutGen.getEnabledOperators());
}

/**
 * Prints the diff between a mutant and the original contract
 * @param {*} argv the hash of the mutant
 */
function diff(argv) {
  setup(() =>
    glob(contractsDir + contractsGlob, (err, contracts) => {
      if (err) {
        console.log(err);
        process.exit(0);
      }
      const mutations = generateMutations(contracts, null, false, false)
      const index = mutationsByHash(mutations)
      if (!index[argv.hash]) {
        console.error(chalk.red('\nError: Mutation ' + argv.hash + ' not found.'))
        process.exit(1)
      }
      console.log(index[argv.hash].diffColor())
    })
  )
}

/**
 * Creates an object containing mutations indexed by their hash values.
 * @param {Array} mutations - An array of mutation objects.
 * @returns {Object} Returns an object with mutations indexed by their hash values.
 */
function mutationsByHash(mutations) {
  return mutations.reduce((obj, mutation) => {
    obj[mutation.hash()] = mutation
    return obj
  }, {})
}

module.exports = {
  lookup: lookup,
  mutate: mutate,
  pretest: runPreTest,
  coverage: runCoverage,
  test: test,
  diff: diff,
  list: enabledOperators,
  enable: enableOperator,
  disable: disableOperator
}
