const contextParser = require("../contextParser");
const Mutation = require('../../mutation')

function UBOOperator() {
    this.ID = "UBO";
    this.name = "unchecked-block-optimization";
}

UBOOperator.prototype.getMutations = function (file, source, visit) {
    const mutations = []
    let mathOperators = ["+", "-", "*", "/", "%", "**"]

    visit({
        ExpressionStatement: (node) => {
            if ((node.expression?.operator === "=" &&
                node.expression.right?.type === "BinaryOperation" && node.expression.right.operator
                && mathOperators.includes(node.expression.right.operator))) {
                const start = node.range[0];
                const end = node.range[1] + 1;
                const functionName = contextParser.getFunctionName(visit,startLine,endLine);
                const startLine = node.loc.start.line;
                const endLine = node.loc.end.line;
                const original = source.slice(start, end)
                let replacement = "unchecked{" + original + "}";
                mutations.push(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, this.ID))
            }
        }
    }
    );

    return mutations
}

module.exports = UBOOperator
