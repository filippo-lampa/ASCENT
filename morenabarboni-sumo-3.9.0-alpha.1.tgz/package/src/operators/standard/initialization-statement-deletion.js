const contextParser = require("../contextParser");
const Mutation = require("../../mutation");

class ISDOperator {
  constructor() {
    this.ID = "ISD";
    this.name = "initialization-statement-deletion";
  }

  getMutations(file, source, visit) {
    const mutations = [];
    const ehFunctions = ["require", "assert", "revert"];
    const skipInitialValues = [0, 1, true, false];

    visit({
      FunctionDefinition: (node) => {
        if (node.isConstructor || node.name === "initialize") {

          if (node.body && node.body.statements) {
            node.body.statements.forEach(s => {

              //All the values iniside skipInitialValues must be skipped as they either generate equivalent mutants, or duplicate mutants w.r.t. to other operators
              if (s.type === "ExpressionStatement" && s.expression.type === "BinaryOperation" && s.expression.operator === "=" && s.expression.right) {

                //Boolean values on the right side are always skipped because they would generate equivalent/duplicate mutants wrt BVR
                //Number values on the right side skipped if equal to 0 or 1, because they would generate equivalent/duplicate mutants wrt NVR
                if (!s.expression.right.type === "BooleanLiteral" && (!s.expression.right.type === "NumberLiteral") ||
                  (s.expression.right.type === "NumberLiteral" && s.expression.right.number !== "0" && s.expression.right.number !== "1")) {
                  mutateCommentOut(s);
                }
              }

              //Do not mutate exception handling functions
              else if (s.type === "ExpressionStatement" && s.expression.type === "FunctionCall" && !ehFunctions.includes(s.expression.expression.name)) {
                mutateCommentOut(s);
              }

              //All the values iniside skipInitialValues must be skipped as they either generate equivalent mutants, or duplicate mutants w.r.t. to other operators
              else if (s.type === "VariableDeclarationStatement" && s.variables.length === 1 && s.initialValue !== null && !skipInitialValues.includes(s.initialValue.value)) {
                mutateDeleteInitialValue(s);
              }
            });
          }
        }
      }
    });

    /**
    * Mutates a node by commenting it out
    * @param {Object} node the node to be mutated
    */
    function mutateCommentOut(node) {
      const start = node.range[0];
      const end = node.range[1] + 1;
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = contextParser.getFunctionName(visit,startLine,endLine);
      const original = source.slice(start, end);
      const replacement = "/* " + original + " */";
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "ISD"));
    }

    /**
   * Mutates a variable declaration by removing its initial value
   * @param {*} node the initial value node to be mutated
   */
    function mutateDeleteInitialValue(node) {
      const start = node.range[0];
      const end = node.range[1] + 1;
      const original = source.slice(start, end);
      const startLine = node.loc.start.line;
      const endLine = node.loc.end.line;
      const functionName = contextParser.getFunctionName(visit,startLine,endLine);
      const startVar = node.variables[0].range[0];
      const endVar = node.variables[0].range[1] + 1;
      const originalLeft = source.slice(startVar, endVar);
      const replacement = originalLeft + ";";
      pushMutation(new Mutation(file, functionName, start, end, startLine, endLine, original, replacement, "ISD"));
    }


    /**
    * Add a mutation to the mutations list
    * @param {*} mutation the mutation object
    */
    function pushMutation(mutation) {
      if (!mutations.find(m => m.id === mutation.id)) {
        mutations.push(mutation);
      }
    }
    return mutations;
  }
}


module.exports = ISDOperator;